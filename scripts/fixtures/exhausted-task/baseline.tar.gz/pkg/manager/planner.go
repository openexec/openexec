package manager

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/openexec/openexec/internal/intent"
	"github.com/openexec/openexec/internal/mcp"
	"github.com/openexec/openexec/internal/planner"
	"github.com/openexec/openexec/internal/project"
	"github.com/openexec/openexec/internal/prompt"
	"github.com/openexec/openexec/internal/release"
	"github.com/openexec/openexec/internal/runner"
)

// PlanRequest defines the input for a planning operation.
type PlanRequest struct {
	// RequestID binds a caller's accepted Goal/Ready/gap request to one durable
	// reviewed plan. It is an identity, not new execution/effect authority.
	RequestID  string `json:"request_id,omitempty"`
	Intent     string `json:"intent,omitempty"`
	IntentFile string `json:"intent_file"`
	NoValidate bool   `json:"no_validate"`
	AutoImport bool   `json:"auto_import"`       // Automatically load stories into DB
	Review     bool   `json:"review"`            // Opt-in task-oriented route: review before import.
	Compact    bool   `json:"compact,omitempty"` // Reuse the small-change planner; same review and native task loop.
}

// PlanResult contains the generated plan and validation status.
type PlanResult struct {
	Plan               *planner.ProjectPlan `json:"plan"`
	Valid              bool                 `json:"valid"`
	Issues             []string             `json:"issues,omitempty"`
	PlanID             string               `json:"plan_id,omitempty"`
	ArtifactHash       string               `json:"artifact_hash,omitempty"`
	ArtifactPath       string               `json:"artifact_path,omitempty"`
	PromptVersion      string               `json:"prompt_version,omitempty"`
	PlannerBuild       string               `json:"planner_build,omitempty"`
	Review             *planner.PlanReview  `json:"review,omitempty"`
	ReviewArtifactPath string               `json:"review_artifact_path,omitempty"`
}

// PlanInputError represents a validation error for plan input.
// It is returned for 400 Bad Request responses.
type PlanInputError struct {
	Message string
}

func (e *PlanInputError) Error() string {
	return e.Message
}

// Plan executes the planning workflow on the server side (V1.0 Service).
func (m *Manager) Plan(ctx context.Context, req PlanRequest) (*PlanResult, error) {
	if req.RequestID != "" {
		return m.replayReviewedPlan(ctx, req)
	}
	if req.Intent != "" {
		return nil, &PlanInputError{Message: "in-memory intent requires a stable reviewed request ID"}
	}
	if req.Review && (m.cfg.PlanGenerator != nil || m.cfg.PlanReviewer != nil) &&
		(m.cfg.PlanGenerator == nil || m.cfg.PlanReviewer == nil) {
		return nil, fmt.Errorf("reviewed planning with admitted adapters requires both generator and reviewer; native fallback refused")
	}
	intentFile := req.IntentFile
	if intentFile == "" {
		intentFile = "INTENT.md"
	}

	// Security: Validate intent_file is constrained to workspace and not in denylist
	absIntentPath := filepath.Join(m.cfg.WorkDir, intentFile)

	// Use mcp path validator to enforce workspace root constraint and denylist
	validator := mcp.NewPathValidator(mcp.PathValidatorConfig{
		AllowedRoots:    []string{m.cfg.WorkDir},
		AllowSymlinks:   false,
		RequireAbsolute: false,
		RequireExists:   true,
		RequireFile:     true,
	})

	validatedPath, err := validator.Validate(absIntentPath)
	if err != nil {
		// Return a typed error so the handler can return 400
		return nil, &PlanInputError{Message: fmt.Sprintf("invalid intent_file: %v", err)}
	}
	absIntentPath = validatedPath

	if _, err := os.Stat(absIntentPath); os.IsNotExist(err) {
		return nil, &PlanInputError{Message: fmt.Sprintf("intent file not found: %s", intentFile)}
	}

	// 1. Validation
	if !req.NoValidate {
		validator := intent.NewValidator(absIntentPath)
		res, err := validator.Validate()
		if err != nil {
			return nil, fmt.Errorf("validation error: %w", err)
		}
		if !res.Valid {
			issues := []string{}
			for _, i := range res.Critical {
				issues = append(issues, i.Message)
			}
			return &PlanResult{Valid: false, Issues: issues}, nil
		}
	}

	// 2. Load Config
	projCfg, err := project.LoadProjectConfig(m.cfg.WorkDir)
	if err != nil {
		projCfg = &project.ProjectConfig{
			Execution: project.ExecutionConfig{PlannerModel: "sonnet"},
		}
	}

	plannerModel := projCfg.Execution.PlannerModel
	if plannerModel == "" {
		plannerModel = m.cfg.ExecutorModel
	}

	// 3. Run Planner
	intentContent, err := os.ReadFile(absIntentPath)
	if err != nil {
		return nil, err
	}

	generator := m.cfg.PlanGenerator
	if generator == nil {
		generator = &cliLLMProvider{model: plannerModel}
	}
	p := planner.New(generator)
	var plan *planner.ProjectPlan
	if req.Compact {
		plan, err = p.GenerateCompactPlan(ctx, string(intentContent))
	} else {
		plan, err = p.GeneratePlan(ctx, string(intentContent), nil)
	}
	if err != nil {
		return nil, fmt.Errorf("planner failed: %w", err)
	}
	if err := plan.Validate(); err != nil {
		return nil, fmt.Errorf("invalid generated plan: %w", err)
	}
	if req.Review && req.AutoImport {
		if err := m.preparePlanIDs(plan); err != nil {
			return nil, err
		}
	}
	var review *planner.PlanReview
	if req.Review {
		reviewer := m.cfg.PlanReviewer
		if reviewer == nil {
			model := projCfg.Execution.ReviewerModel
			if model == "" {
				model = plannerModel
			}
			reviewer = &cliLLMProvider{model: model}
		}
		review, err = planner.New(reviewer).ReviewPlan(ctx, string(intentContent), plan)
		if err != nil {
			return nil, err
		}
	}

	// Write plan artifact to .openexec/artifacts/plans/<hash>.json
	planID, artifactHash, artifactPath := m.writePlanArtifact(plan)
	var reviewPath string
	if req.Review {
		if artifactPath == "" {
			return nil, fmt.Errorf("reviewed plan artifact was not persisted; import refused")
		}
		// Reuse content-addressed plan artifacts for review provenance. Different
		// reviews of the same plan must not overwrite one another.
		data, err := json.Marshal(struct {
			PlanDigest string              `json:"plan_digest"`
			Review     *planner.PlanReview `json:"review"`
		}{artifactHash, review})
		if err != nil {
			return nil, err
		}
		digest := sha256.Sum256(data)
		reviewPath = filepath.Join(filepath.Dir(artifactPath), hex.EncodeToString(digest[:])+".review.json")
		if err := m.writePlanEvidence(reviewPath, data, 0600); err != nil {
			return nil, fmt.Errorf("persist plan review: %w", err)
		}
		if !review.Approved {
			return &PlanResult{Plan: plan, Valid: false, Review: review, Issues: []string{review.Assessment}, PlanID: planID, ArtifactHash: artifactHash, ArtifactPath: artifactPath, ReviewArtifactPath: reviewPath}, nil
		}
	}

	// Auto-import: persist stories/tasks to DB so runs:execute can find them
	if req.AutoImport {
		if err := m.importBoundPlan(plan, req.Review); err != nil {
			return nil, fmt.Errorf("failed to import plan to database: %w", err)
		}
	}

	return &PlanResult{
		Plan:               plan,
		Valid:              true,
		PlanID:             planID,
		ArtifactHash:       artifactHash,
		ArtifactPath:       artifactPath,
		PromptVersion:      prompt.PromptVersion,
		Review:             review,
		ReviewArtifactPath: reviewPath,
	}, nil
}

// writePlanArtifact persists a plan to the artifacts directory and returns its ID and hash.
func (m *Manager) writePlanArtifact(plan *planner.ProjectPlan) (planID, artifactHash, artifactPath string) {
	// Generate plan ID from timestamp
	planID = fmt.Sprintf("PLAN-%s", time.Now().UTC().Format("20060102-150405"))

	// Validate plan before writing to avoid malformed artifacts
	if err := plan.Validate(); err != nil {
		return planID, "", ""
	}

	// Serialize plan to JSON
	data, err := json.MarshalIndent(plan, "", "  ")
	if err != nil {
		return planID, "", ""
	}

	// Compute content hash
	hash := sha256.Sum256(data)
	artifactHash = hex.EncodeToString(hash[:])

	// Write to artifacts directory
	dir := filepath.Join(m.cfg.WorkDir, ".openexec", "artifacts", "plans")
	artifactPath = filepath.Join(dir, artifactHash+".json")
	if err := m.writePlanEvidence(artifactPath, data, 0644); err != nil {
		return planID, artifactHash, ""
	}

	return planID, artifactHash, artifactPath
}

// Root-relative I/O prevents candidate-controlled symlinks from escaping the
// admitted workspace, including a swap after an ordinary path check.
func (m *Manager) writePlanEvidence(path string, data []byte, mode os.FileMode) error {
	root, err := os.OpenRoot(m.cfg.WorkDir)
	if err != nil {
		return err
	}
	defer root.Close()
	rel, err := filepath.Rel(m.cfg.WorkDir, path)
	if err != nil {
		return err
	}
	if err = root.MkdirAll(filepath.Dir(rel), 0755); err != nil {
		return err
	}
	return root.WriteFile(rel, data, mode)
}

func (m *Manager) readPlanEvidence(path string) ([]byte, error) {
	root, err := os.OpenRoot(m.cfg.WorkDir)
	if err != nil {
		return nil, err
	}
	defer root.Close()
	rel, err := filepath.Rel(m.cfg.WorkDir, path)
	if err != nil {
		return nil, err
	}
	return root.ReadFile(rel)
}

func (m *Manager) importPlan(plan *planner.ProjectPlan) error {
	return m.importBoundPlan(plan, false)
}

func (m *Manager) preparePlanIDs(plan *planner.ProjectPlan) error {
	rel, err := m.GetInternalReleaseManager()
	if err != nil {
		return err
	}

	if err := rel.Load(); err != nil {
		return err
	}
	if err := uniquePlanIDs(plan); err != nil {
		return err
	}

	// Re-plan support: the generator always numbers from US-001/G-001, so a
	// second plan (refactor epic, post-build feature wave) collides with the
	// existing backlog. Remap genuinely-new colliding IDs to free ones;
	// identical importer content stays put, including populated task mappings.
	remapped := planner.RemapPlanIDs(plan, planner.ExistingLookup{
		Conflicts: func(candidate *planner.ProjectPlan) map[string]bool {
			return reviewedIdentityConflicts(rel, candidate)
		},
		GoalTitle: func(id string) (string, bool) {
			if g := rel.GetGoal(id); g != nil {
				return g.Title, true
			}
			return "", false
		},
		StoryTitle: func(id string) (string, bool) {
			if s := rel.GetStory(id); s != nil {
				return s.Title, true
			}
			return "", false
		},
		TaskExists: func(id string) bool { return rel.GetTask(id) != nil },
	})
	if remapped > 0 {
		log.Printf("[Planner] Re-plan detected: remapped %d colliding IDs so the new plan appends to the existing backlog", remapped)
	}
	return nil
}

func (m *Manager) importBoundPlan(plan *planner.ProjectPlan, reviewed bool) error {
	// Last step before persistence on the native and non-reviewed routes: a
	// reviewer's approval does not exempt a plan from the stale-base rule.
	if err := planner.PlanStaleBaseRefError(plan); err != nil {
		return err
	}
	before, err := json.Marshal(plan)
	if err != nil {
		return err
	}
	if err := m.preparePlanIDs(plan); err != nil {
		return err
	}
	after, err := json.Marshal(plan)
	if err != nil {
		return err
	}
	if reviewed && string(before) != string(after) {
		return fmt.Errorf("backlog changed after plan review; changed task identities require review")
	}
	rel, err := m.GetInternalReleaseManager()
	if err != nil {
		return err
	}

	now := time.Now()
	var importedGoals, importedStories, importedTasks int

	// 1. Create goals first (stories reference them via FK)
	importedGoalIDs := make(map[string]bool)
	for _, g := range plan.Goals {
		if rel.GetGoal(g.ID) == nil {
			goal := &release.Goal{
				ID:                 g.ID,
				Title:              g.Title,
				Description:        g.Description,
				SuccessCriteria:    g.SuccessCriteria,
				VerificationMethod: g.VerificationMethod,
			}
			if err := rel.CreateGoal(goal); err != nil {
				return fmt.Errorf("import goal %s: %w", g.ID, err)
			}
			importedGoals++
		}
		importedGoalIDs[g.ID] = true
	}

	// 2. Create stories and tasks
	for i, s := range plan.Stories {
		if rel.GetStory(s.ID) == nil {
			// Validate GoalID exists
			goalID := s.GoalID
			if goalID != "" && !importedGoalIDs[goalID] && rel.GetGoal(goalID) == nil {
				log.Printf("[Planner] Warning: Story %s references unknown Goal %s. Clearing GoalID.", s.ID, goalID)
				goalID = ""
			}

			st := &release.Story{
				ID:                 s.ID,
				GoalID:             goalID,
				Title:              s.Title,
				Description:        s.Description,
				AcceptanceCriteria: s.AcceptanceCriteria,
				VerificationScript: s.VerificationScript,
				Contract:           s.Contract,
				DependsOn:          s.DependsOn,
				StoryType:          release.StoryTypeFeature,
				Priority:           i,
				Status:             release.StoryStatusPending,
				CreatedAt:          now,
			}
			if st.AcceptanceCriteria == nil {
				st.AcceptanceCriteria = []string{}
			}
			if st.DependsOn == nil {
				st.DependsOn = []string{}
			}
			if err := rel.CreateStory(st); err != nil {
				return fmt.Errorf("import story %s: %w", s.ID, err)
			}
			importedStories++
		}

		for j, t := range s.Tasks {
			if rel.GetTask(t.ID) == nil {
				description := t.Description
				if strings.TrimSpace(t.TechnicalStrategy) != "" {
					description += "\n\nTechnical strategy:\n" + t.TechnicalStrategy
				}
				task := &release.Task{
					ID:                 t.ID,
					Title:              t.Title,
					Description:        description,
					VerificationScript: t.VerificationScript,
					StoryID:            s.ID,
					DependsOn:          t.DependsOn,
					Priority:           j,
					MaxAttempts:        3,
					Status:             release.TaskStatusPending,
					CreatedAt:          now,
				}
				if task.DependsOn == nil {
					task.DependsOn = []string{}
				}
				task.Metadata = t.ExecutionMetadata()

				if err := rel.CreateTask(task); err != nil {
					return fmt.Errorf("import task %s: %w", t.ID, err)
				}
				importedTasks++
			}
		}
	}

	log.Printf("[Planner] Imported %d goals, %d stories, %d tasks into database", importedGoals, importedStories, importedTasks)
	return nil
}

type cliLLMProvider struct {
	model string
}

func (p *cliLLMProvider) Complete(ctx context.Context, prompt string) (string, error) {
	cliCmd, cmdArgs, err := runner.Resolve(
		p.model,
		os.Getenv("OPENEXEC_PLANNER_CLI"),
		strings.Fields(os.Getenv("OPENEXEC_PLANNER_ARGS")),
	)
	if err != nil {
		return "", err
	}

	if strings.Contains(strings.ToLower(cliCmd), "claude") {
		cmdArgs = []string{"--print"}
	}

	c := exec.CommandContext(ctx, cliCmd, cmdArgs...)
	c.Stdin = strings.NewReader(prompt)

	output, err := c.CombinedOutput()
	if err != nil {
		outStr := string(output)
		if strings.Contains(outStr, "authentication_error") || strings.Contains(outStr, "OAuth token has expired") {
			return "", fmt.Errorf("\n❌ AI Provider Authentication Failed. Please run: %s login", cliCmd)
		}
		return "", fmt.Errorf("native LLM provider failed: %w\nOutput: %s", err, outStr)
	}

	return string(output), nil
}
