package pipeline

import (
	"context"
	"database/sql"
	"fmt"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/openexec/openexec/internal/actions"
	"github.com/openexec/openexec/internal/blueprint"
	"github.com/openexec/openexec/internal/cache"
	"github.com/openexec/openexec/internal/checkpoint"
	"github.com/openexec/openexec/internal/config"
	ocontext "github.com/openexec/openexec/internal/context"
	"github.com/openexec/openexec/internal/execution/gates"
	"github.com/openexec/openexec/internal/loop"
	"github.com/openexec/openexec/internal/project"
	"github.com/openexec/openexec/internal/quality"
	"github.com/openexec/openexec/internal/router"
	"github.com/openexec/openexec/internal/skills"
	"github.com/openexec/openexec/internal/toolset"
	"github.com/openexec/openexec/internal/types"
	pagent "github.com/openexec/openexec/pkg/agent"
	"github.com/openexec/openexec/pkg/telemetry"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
)

// Config controls pipeline behavior.
type Config struct {
	// StageExecutor supplies admitted execution; nil retains standalone execution.
	StageExecutor blueprint.StageExecutor
	// RecaptureStage restricts this run to one resolved deterministic check.
	RecaptureStage       *blueprint.Stage
	FWUID                string
	WorkDir              string
	AgentsFS             fs.FS
	ExecutorModel        string   // model for runner resolution
	RunnerCommand        string   // CLI override
	RunnerArgs           []string // CLI args override
	DefaultMaxIterations int      // default 10
	MaxRetries           int      // default 3
	RetryBackoff         []time.Duration
	ThrashThreshold      int      // default 3
	CommandName          string   // test override
	CommandArgs          []string // test override

	// IsStudy flags the task as documentation/analysis only.
	IsStudy bool

	// Log configuration
	LogDir string

	// Evidence configuration
	EvidenceDir      string
	EvidenceBucket   string
	EvidenceRegion   string
	EvidenceEndpoint string
	EvidencePrefix   string

	// ExecMode: read-only | workspace-write | danger-full-access
	ExecMode string

	// ResumeFrom enables resuming from a checkpoint.
	ResumeFrom *ResumeConfig

	// BlueprintID enables blueprint mode with the specified blueprint.
	// When set, the pipeline uses blueprint-based execution instead of phases.
	BlueprintID string

	// ReviewEnabled enables the code review stage after testing.
	ReviewEnabled bool

	// ReviewerModel optionally overrides the model used for the review stage.
	ReviewerModel string

	// TaskDescription is the user's task description for blueprint runs.
	TaskDescription string

	// ContextTokenBudget is the token budget for context assembly.
	// If > 0, context is gathered using two-stage assembly.
	ContextTokenBudget int

	// RepoZones filters context to specific directories.
	RepoZones []string

	// KnowledgeSources ranks context items by source relevance.
	KnowledgeSources []string

	// Sensitivity determines redaction level ("low", "medium", "high").
	Sensitivity string

	// TaskTimeout overrides the default implement stage timeout.
	// If zero, the blueprint default (10 minutes) is used.
	TaskTimeout time.Duration

	// API provider settings for OpenAI-compatible execution
	APIProvider string // "openai_compat"
	APIBaseURL  string // e.g. "https://api.moonshot.cn/v1"
	APIKey      string // API key or "$ENV_VAR" reference
	APIModel    string // e.g. "moonshot-v1-128k"

	// SelectedToolset is the toolset name chosen by the local router for this
	// task. Populated in runBlueprintMode from RoutingPlan.Toolset and consumed
	// by createAPIAgenticLoop when ToolsetFiltering is enabled. See ADR-002.
	SelectedToolset string

	// ToolsetFiltering enables sending only the SelectedToolset's tools in
	// API requests instead of the full hardcoded list. Mirrors the
	// execution.toolset_filtering project config flag.
	ToolsetFiltering bool

	// StateDB is the underlying *sql.DB from the state store, passed through
	// so the pre-resolver can query the symbols table without opening a new
	// connection. May be nil when running outside the daemon.
	StateDB *sql.DB

	// PreResolvedContext holds pre-resolved symbol context injected by the
	// Layer 2 pre-resolver. Populated in runBlueprintMode before briefing
	// assembly and appended to input.Briefing.
	PreResolvedContext string

	// LocalPreResolveEnabled mirrors the project feature flag. When true
	// (default), the pre-resolver pre-pass runs before the implement stage.
	LocalPreResolveEnabled bool
}

// ResumeConfig holds configuration for resuming from a checkpoint.
type ResumeConfig struct {
	CheckpointID     string   // ID of the checkpoint to resume from
	Phase            string   // Phase to resume from
	Iteration        int      // Iteration to resume from
	MessageHistory   []byte   // JSON-encoded message history
	AppliedToolCalls []string // Idempotency keys of already-applied tool calls
}

// Pipeline drives an FWU through blueprint-based stage execution.
// It coordinates with the blueprint engine to execute stages like
// gather_context → implement → lint → test → review.
type Pipeline struct {
	cfg     Config
	factory *LoopFactory
	events  chan loop.Event

	gateRunner     types.GateRunner
	qualityManager *quality.Manager
	checkpointMgr  *checkpoint.Manager

	intentRouter router.Router

	skillRegistry *skills.Registry

	knowledgeCache  *cache.KnowledgeCache
	toolResultCache *cache.ToolResultCache
	contextPruner   *ocontext.Pruner

	currentLoop *loop.Loop
	mu          sync.Mutex

	paused  atomic.Bool
	stopped atomic.Bool
}

// New creates a Pipeline and returns it along with a read-only event channel.
// The channel is closed when Run returns.
func New(cfg Config, opts ...Option) (*Pipeline, <-chan loop.Event) {
	factory := NewLoopFactory(LoopFactoryConfig{
		FWUID:                cfg.FWUID,
		WorkDir:              cfg.WorkDir,
		AgentsFS:             cfg.AgentsFS,
		DefaultMaxIterations: cfg.DefaultMaxIterations,
		MaxRetries:           cfg.MaxRetries,
		RetryBackoff:         cfg.RetryBackoff,
		ThrashThreshold:      cfg.ThrashThreshold,
		ExecutorModel:        cfg.ExecutorModel,
		RunnerCommand:        cfg.RunnerCommand,
		RunnerArgs:           cfg.RunnerArgs,
		CommandName:          cfg.CommandName,
		CommandArgs:          cfg.CommandArgs,
		LogDir:               cfg.LogDir,
		EvidenceDir:          cfg.EvidenceDir,
		EvidenceBucket:       cfg.EvidenceBucket,
		EvidenceRegion:       cfg.EvidenceRegion,
		EvidenceEndpoint:     cfg.EvidenceEndpoint,
		EvidencePrefix:       cfg.EvidencePrefix,
		ExecMode:             cfg.ExecMode,
	})
	return NewWithFactory(cfg, factory, opts...)
}

// Option defines a functional option for Pipeline.
type Option func(*Pipeline)

// WithGateRunner sets the quality gate runner for the pipeline.
func WithGateRunner(runner types.GateRunner) Option {
	return func(p *Pipeline) {
		p.gateRunner = runner
	}
}

// WithQualityManager sets the V2 quality gate manager for the pipeline.
func WithQualityManager(qm *quality.Manager) Option {
	return func(p *Pipeline) {
		p.qualityManager = qm
	}
}

// WithCheckpointManager sets the checkpoint manager for crash recovery.
func WithCheckpointManager(m *checkpoint.Manager) Option {
	return func(p *Pipeline) {
		p.checkpointMgr = m
	}
}

// WithKnowledgeCache sets the knowledge cache for the pipeline.
func WithKnowledgeCache(c *cache.KnowledgeCache) Option {
	return func(p *Pipeline) { p.knowledgeCache = c }
}

// WithToolResultCache sets the tool result cache for the pipeline.
func WithToolResultCache(c *cache.ToolResultCache) Option {
	return func(p *Pipeline) { p.toolResultCache = c }
}

// WithContextPruner sets the context pruner for reducing token usage by selecting
// only the most relevant context items for a given task.
func WithContextPruner(cp *ocontext.Pruner) Option {
	return func(p *Pipeline) { p.contextPruner = cp }
}

// WithSkillRegistry sets the skill registry for injecting relevant skills into pipeline context.
func WithSkillRegistry(r *skills.Registry) Option {
	return func(p *Pipeline) { p.skillRegistry = r }
}

// WithRouter sets the intent router for deterministic task routing.
func WithRouter(r router.Router) Option {
	return func(p *Pipeline) { p.intentRouter = r }
}

// NewWithFactory creates a Pipeline using a pre-configured factory.
func NewWithFactory(cfg Config, factory *LoopFactory, opts ...Option) (*Pipeline, <-chan loop.Event) {
	// Apply defaults for blueprint-based execution.
	if cfg.DefaultMaxIterations == 0 {
		cfg.DefaultMaxIterations = config.DefaultMaxIterations
	}
	if cfg.MaxRetries == 0 {
		cfg.MaxRetries = config.DefaultMaxRetries
	}
	if cfg.RetryBackoff == nil {
		cfg.RetryBackoff = config.DefaultRetryBackoff
	}
	if cfg.ThrashThreshold == 0 {
		cfg.ThrashThreshold = config.DefaultThrashThreshold
	}

	ch := make(chan loop.Event, 64)

	p := &Pipeline{
		cfg:     cfg,
		factory: factory,
		events:  ch,
	}

	for _, opt := range opts {
		opt(p)
	}

	return p, ch
}

// Run executes the pipeline using blueprint-based stage orchestration.
// It closes the event channel when it returns.
//
// Note: Legacy phase-based execution has been removed. All pipeline execution
// now uses blueprint mode. If BlueprintID is not set, "standard_task" is used.
func (p *Pipeline) Run(ctx context.Context) error {
	ctx, span := telemetry.StartSpan(ctx, "Pipeline.Run", trace.WithAttributes(
		attribute.String("fwu_id", p.cfg.FWUID),
		attribute.String("project_path", p.cfg.WorkDir),
	))
	defer span.End()

	defer close(p.events)

	// Always use blueprint mode - default to standard_task if not specified
	return p.runBlueprintMode(ctx)
}

// Pause signals the pipeline to exit after the current loop iteration.
func (p *Pipeline) Pause() {
	p.paused.Store(true)
	p.mu.Lock()
	if p.currentLoop != nil {
		p.currentLoop.Pause()
	}
	p.mu.Unlock()
}

// Stop signals the pipeline to kill the current process and exit immediately.
func (p *Pipeline) Stop() {
	p.stopped.Store(true)
	p.mu.Lock()
	if p.currentLoop != nil {
		p.currentLoop.Stop()
	}
	p.mu.Unlock()
}

// Close releases resources held by the pipeline.
func (p *Pipeline) Close() {
	if p.checkpointMgr != nil {
		p.checkpointMgr.Close()
	}
	if p.knowledgeCache != nil {
		p.knowledgeCache.Close()
	}
	if p.toolResultCache != nil {
		p.toolResultCache.Close()
	}
	if p.contextPruner != nil {
		p.contextPruner.Close()
	}
}

func (p *Pipeline) emit(e loop.Event) {
	p.events <- e
}

func (p *Pipeline) buildMCPConfig() (string, func(), error) {
	if p.cfg.CommandName != "" {
		// Test mode — no real MCP config needed.
		return "", func() {}, nil
	}

	axonBin, _ := os.Executable()
	servers := loop.BuildMCPServers(axonBin, "")
	path, err := loop.WriteMCPConfig(servers)
	if err != nil {
		return "", nil, err
	}
	return path, func() { _ = os.Remove(path) }, nil
}

// GetHealth returns health information about the current phase loop.
func (p *Pipeline) GetHealth() (loop.LoopHealth, bool) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.currentLoop == nil {
		return loop.LoopHealth{}, false
	}
	return p.currentLoop.GetHealth(), true
}

// runBlueprintMode executes the pipeline using blueprint-based stage orchestration.
// This is the sole execution path - all pipeline runs use blueprint mode.
// If BlueprintID is empty, it defaults to "standard_task".
func (p *Pipeline) runBlueprintMode(ctx context.Context) error {
	// Deterministic routing: classify task and set context parameters
	if p.cfg.RecaptureStage == nil && p.cfg.StageExecutor == nil && p.intentRouter != nil && p.cfg.TaskDescription != "" {
		// Pass a real toolset registry so RoutingPlan.Toolset gets populated
		// via intent-based lookup as well as the keyword selector. Previously
		// nil, which forced selectToolset down its keyword-only path.
		registry := toolset.NewRegistry()
		plan, err := router.Route(ctx, p.intentRouter, p.cfg.TaskDescription, registry)
		if err == nil {
			if len(plan.RepoZones) > 0 && len(p.cfg.RepoZones) == 0 {
				p.cfg.RepoZones = plan.RepoZones
			}
			if len(plan.KnowledgeSources) > 0 && len(p.cfg.KnowledgeSources) == 0 {
				p.cfg.KnowledgeSources = plan.KnowledgeSources
			}
			if plan.Sensitivity != "" && p.cfg.Sensitivity == "" {
				p.cfg.Sensitivity = string(plan.Sensitivity)
			}
			// Store the routed toolset so createAPIAgenticLoop can filter
			// req.Tools when ToolsetFiltering is enabled. See ADR-002.
			if plan.Toolset != "" && p.cfg.SelectedToolset == "" {
				p.cfg.SelectedToolset = plan.Toolset
			}
		}
	}

	// Pre-resolve symbols from task description (Layer 2)
	if p.cfg.RecaptureStage == nil && p.cfg.StageExecutor == nil && p.cfg.LocalPreResolveEnabled && p.cfg.TaskDescription != "" && p.cfg.StateDB != nil {
		pr := &PreResolver{}
		preResolved := pr.Resolve(ctx, p.cfg.TaskDescription, p.cfg.WorkDir, p.cfg.StateDB)
		if preResolved != "" {
			p.cfg.PreResolvedContext = preResolved
		}
	}

	// Build context using two-stage assembly
	var contextPack *ocontext.ContextPack
	if p.cfg.RecaptureStage == nil && p.cfg.StageExecutor == nil && p.cfg.ContextTokenBudget > 0 {
		pack, err := ocontext.BuildContextWithRouting(
			ctx,
			p.cfg.WorkDir,
			p.cfg.ContextTokenBudget,
			p.cfg.RepoZones,
			p.cfg.KnowledgeSources,
			p.cfg.Sensitivity,
		)
		if err != nil {
			// Log warning but continue - context is optional
			p.emit(loop.Event{
				Type:    loop.EventError,
				FWUID:   p.cfg.FWUID,
				ErrText: fmt.Sprintf("context assembly warning: %v", err),
			})
		} else {
			contextPack = pack
		}
	}

	// Prune context to reduce token usage
	if p.contextPruner != nil && contextPack != nil && len(contextPack.Items) > 0 {
		files := make([]ocontext.FileInfo, 0, len(contextPack.Items))
		for _, item := range contextPack.Items {
			files = append(files, ocontext.FileInfo{
				Path:    item.Source,
				Content: item.Content,
			})
		}
		if pruned, err := p.contextPruner.Prune(files, p.cfg.TaskDescription); err == nil && len(pruned.Files) > 0 {
			prunedItems := make([]*ocontext.ContextItem, 0, len(pruned.Files))
			for _, pf := range pruned.Files {
				prunedItems = append(prunedItems, &ocontext.ContextItem{
					Type:    ocontext.ContextTypeRecentFiles,
					Source:  pf.Path,
					Content: pf.Content,
				})
			}
			contextPack.Items = prunedItems
			contextPack.TotalTokens = pruned.TotalTokens
		}
	}

	// Lookup blueprint by ID
	var bp *blueprint.Blueprint
	switch p.cfg.BlueprintID {
	case "standard_task", "":
		bp = blueprint.DefaultBlueprint
	case "quick_fix":
		bp = blueprint.QuickFixBlueprint
	default:
		// Try to load from external file in .openexec/blueprints/
		absWorkDir, _ := filepath.Abs(p.cfg.WorkDir)
		bpPath := filepath.Join(absWorkDir, ".openexec", "blueprints", p.cfg.BlueprintID+".yaml")
		log.Printf("[Pipeline] Loading external blueprint from: %s", bpPath)
		if _, err := os.Stat(bpPath); err == nil {
			reg := blueprint.NewRegistry()
			if externalBP, err := reg.LoadFromFile(bpPath); err == nil {
				bp = externalBP
			} else {
				return fmt.Errorf("failed to load blueprint from %s: %w", bpPath, err)
			}
		} else {
			return fmt.Errorf("unknown blueprint: %s", p.cfg.BlueprintID)
		}
	}

	// Override implement stage timeout if configured
	// The built-in blueprints are shared package-level values, and the block
	// below writes this run's timeout and commands into the stages.
	bp = bp.Clone()

	if p.cfg.TaskTimeout > 0 {
		if impl, ok := bp.Stages["implement"]; ok {
			impl.Timeout = p.cfg.TaskTimeout
		}
	}

	// Override lint/test commands from project config
	verificationStages := make(map[*blueprint.Stage]bool)
	if projCfg, err := project.LoadProjectConfig(p.cfg.WorkDir); err == nil {
		if lint, ok := bp.Stages["lint"]; ok && len(projCfg.Execution.LintCommands) > 0 {
			lint.Commands = projCfg.Execution.LintCommands
			verificationStages[lint] = true
		}
		if test, ok := bp.Stages["test"]; ok && len(projCfg.Execution.TestCommands) > 0 {
			test.Commands = projCfg.Execution.TestCommands
			verificationStages[test] = true
		}
	}

	if p.cfg.RecaptureStage != nil {
		stage := *p.cfg.RecaptureStage
		namedCheck := len(stage.Commands) == 0 && (stage.Name == "lint" || stage.Name == "test")
		if stage.Type != types.StageTypeDeterministic || (!namedCheck && len(stage.Commands) != 1) || stage.Action != "" {
			return fmt.Errorf("invalid verification recapture stage")
		}
		if namedCheck && p.cfg.StageExecutor == nil {
			definition := bp.Stages[stage.Name]
			if definition == nil || definition.Type != types.StageTypeDeterministic || definition.Action != "" || len(definition.Commands) == 0 {
				return fmt.Errorf("current verification check %s has no authoritative command", stage.Name)
			}
			stage.Commands = append([]string(nil), definition.Commands...)
		}
		stage.MaxRetries, stage.OnFailure, stage.OnSuccess = 0, "", ""
		stage.RunQualityGates, stage.CreateCheckpoint = false, false
		bp = &blueprint.Blueprint{ID: "verification_recapture", Name: "Verification recapture", InitialStage: stage.Name, Stages: map[string]*blueprint.Stage{stage.Name: &stage}}
		verificationStages = map[*blueprint.Stage]bool{&stage: true}
	}

	// Create executor with agentic runner
	trustedGates := &gateRunnerAction{runner: p.gateRunner}
	var executor blueprint.StageExecutor
	if p.cfg.StageExecutor != nil {
		executor = admittedStageExecutor{executor: p.cfg.StageExecutor, evidence: trustedGates}
	} else {
		defaultExecutor := blueprint.NewDefaultExecutor(p.cfg.WorkDir)
		defaultExecutor.ActionRegistry = actions.DefaultRegistry(p.cfg.WorkDir)
		defaultExecutor.VerificationStages = verificationStages
		if p.gateRunner != nil {
			defaultExecutor.ActionRegistry.Overwrite(trustedGates)
		}
		defaultExecutor.OnVerificationFailure = func(stage *blueprint.Stage, err error) {
			trustedGates.receipt = gates.VerificationFailureArtifacts(err)
		}

		// Set up agentic runner that wraps a bounded loop
		defaultExecutor.AgenticRunner = &blueprint.LoopAgenticRunner{
			MaxIterations: p.cfg.DefaultMaxIterations,
			LoopFactory: func(stageName string, prompt string, workDir string, maxIterations int) (blueprint.AgenticLoop, error) {
				// Model tiering: Use ReviewerModel for review stage if configured
				model := p.cfg.ExecutorModel
				if stageName == "review" && p.cfg.ReviewerModel != "" {
					model = p.cfg.ReviewerModel
				}
				return p.createAgenticLoop(ctx, model, prompt, workDir, maxIterations)
			},
		}
		executor = defaultExecutor
	}

	// Create engine with callbacks that emit events
	engineConfig := blueprint.DefaultEngineConfig()
	engineConfig.OnStageStart = func(run *blueprint.Run, stageName string) {
		if trustedGates != nil {
			trustedGates.receipt = nil
		}
		p.emit(loop.Event{
			Type:      loop.EventStageStart,
			FWUID:     p.cfg.FWUID,
			StageName: stageName,
		})
	}
	engineConfig.OnStageComplete = func(run *blueprint.Run, result *blueprint.StageResult) {
		eventType := loop.EventStageComplete
		if result.Status == types.StageStatusFailed {
			eventType = loop.EventStageFailed
		}
		p.emit(loop.Event{
			Type:      eventType,
			FWUID:     p.cfg.FWUID,
			StageName: result.StageName,
			StageType: string(result.Status),
			Attempt:   result.Attempt,
			Text:      result.Output,
			ErrText:   result.Error,
			Artifacts: result.Artifacts,
		})

		// Run quality gates after successful stages that opt in
		stage, _ := bp.GetStage(result.StageName)
		if p.cfg.StageExecutor == nil && p.qualityManager != nil && result.Status == types.StageStatusCompleted && stage != nil && stage.RunQualityGates {
			go func() {
				summary, err := p.qualityManager.RunAll(context.Background())
				if err != nil {
					p.emit(loop.Event{Type: loop.EventError, ErrText: fmt.Sprintf("quality gates error: %v", err)})
					return
				}
				if summary.FailedGates > 0 {
					p.emit(loop.Event{
						Type:  loop.EventGatesFailed,
						Text:  fmt.Sprintf("Quality gates: %d passed, %d failed, blocked=%v", summary.PassedGates, summary.FailedGates, summary.Blocked),
						FWUID: p.cfg.FWUID,
					})
				} else {
					p.emit(loop.Event{
						Type:  loop.EventGatesPassed,
						Text:  fmt.Sprintf("Quality gates: %d passed", summary.PassedGates),
						FWUID: p.cfg.FWUID,
					})
				}
			}()
		}

		// Create checkpoint after successful stages for crash recovery
		if p.cfg.StageExecutor == nil && p.checkpointMgr != nil && result.Status == types.StageStatusCompleted {
			go func() {
				if _, err := p.checkpointMgr.Create(run, p.cfg.WorkDir); err != nil {
					p.emit(loop.Event{Type: loop.EventError, ErrText: fmt.Sprintf("checkpoint error: %v", err)})
				}
			}()
		}

	}
	engineConfig.OnCheckpoint = func(run *blueprint.Run, stageName string) {
		p.emit(loop.Event{
			Type:      loop.EventCheckpointCreated,
			FWUID:     p.cfg.FWUID,
			StageName: stageName,
			Artifacts: map[string]string{
				"checkpoint_stage": stageName,
				"run_id":           run.ID,
			},
		})
	}
	engineConfig.OnRunComplete = func(run *blueprint.Run) {
		// Collect all artifacts from stage results
		allArtifacts := make(map[string]string)
		for _, result := range run.Results {
			for k, v := range result.Artifacts {
				allArtifacts[k] = v
			}
		}
		p.emit(loop.Event{
			Type:  loop.EventBlueprintComplete,
			FWUID: p.cfg.FWUID,
			Result: &loop.StepResult{
				Status:     "complete",
				Reason:     "blueprint_complete",
				NextPhase:  "done",
				Artifacts:  allArtifacts,
				Confidence: 1.0,
			},
		})
	}

	engine, err := blueprint.NewEngine(bp, executor, engineConfig)
	if err != nil {
		return fmt.Errorf("create blueprint engine: %w", err)
	}

	// Emit blueprint start event
	p.emit(loop.Event{
		Type:        loop.EventBlueprintStart,
		FWUID:       p.cfg.FWUID,
		BlueprintID: bp.ID,
	})

	// Create run and input
	run, err := engine.StartRun(ctx, p.cfg.FWUID, nil)
	if err != nil {
		return fmt.Errorf("start blueprint run: %w", err)
	}

	input := blueprint.NewStageInput(p.cfg.FWUID, p.cfg.TaskDescription, p.cfg.WorkDir)

	// Inject rich context from ReleaseManager briefing if available
	if p.factory != nil && p.factory.cfg.ReleaseManager != nil {
		if brief, err := p.factory.cfg.ReleaseManager.Brief(p.cfg.FWUID); err == nil && brief != nil {
			// Format using prompt assembler style
			input.Briefing = p.factory.assembler.FormatBriefing(brief)
		}
	}

	// Inject gathered context into stage input
	if contextPack != nil {
		items := make([]blueprint.ContextPackItem, 0, len(contextPack.Items))
		for _, item := range contextPack.Items {
			items = append(items, blueprint.ContextPackItem{
				Type:    string(item.Type),
				Source:  item.Source,
				Content: item.Content,
			})
		}
		input.SetContextFromPack(items)
	}

	// Inject relevant skills into briefing
	if p.skillRegistry != nil && p.cfg.TaskDescription != "" {
		selected := p.skillRegistry.SelectForTask(p.cfg.TaskDescription)
		for _, skill := range selected {
			input.Briefing += fmt.Sprintf("\n\n--- Skill: %s ---\n%s", skill.Name, skill.Content)
		}
	}

	// Inject pre-resolved symbol context into briefing (Layer 2)
	if p.cfg.PreResolvedContext != "" {
		input.Briefing += "\n\n" + p.cfg.PreResolvedContext
	}

	// Handle conditional review stage
	if !p.cfg.ReviewEnabled {
		if test, ok := bp.Stages["test"]; ok {
			test.OnSuccess = "complete"
		}
	} else if p.cfg.ReviewerModel != "" {
		// Use specialized model for review if configured
		if _, ok := bp.Stages["review"]; ok {
			// Model tiering is handled in the LoopAgenticRunner setup
		}
	}

	// Execute the blueprint through the deterministic engine.
	execErr := engine.Execute(ctx, run, input)

	if execErr != nil {
		failureArtifacts := make(map[string]string)
		last := run.GetLastResult()
		stageName, output, diagnostics := "", "", ""
		attempt := 0
		if last != nil {
			stageName, output, diagnostics, attempt = last.StageName, last.Output, last.Diagnostics, last.Attempt
			for key, value := range last.Artifacts {
				// References are evidence, never authority to create repair work.
				if key != gates.VerificationFailureReceiptKey && key != gates.VerificationFailureDigestKey {
					failureArtifacts[key] = value
				}
			}
		}
		if trustedGates != nil && ctx.Err() == nil {
			for key, value := range trustedGates.terminalEvidence(bp, run) {
				failureArtifacts[key] = value
			}
		}
		if p.cfg.RecaptureStage != nil && len(p.cfg.RecaptureStage.Commands) == 0 {
			failureArtifacts["recapture_definition"] = "current-check-definition"
		}
		p.emit(loop.Event{
			Type:        loop.EventBlueprintFailed,
			FWUID:       p.cfg.FWUID,
			BlueprintID: bp.ID,
			StageName:   stageName,
			Attempt:     attempt,
			Text:        output,
			Result:      &loop.StepResult{Status: "failed", Diagnostics: diagnostics},
			ErrText:     execErr.Error(),
			Artifacts:   failureArtifacts,
		})
		return execErr
	}

	// Emit pipeline complete for compatibility
	p.emit(loop.Event{
		Type:  loop.EventPipelineComplete,
		FWUID: p.cfg.FWUID,
	})

	return nil
}

// createAgenticLoop creates a bounded loop for agentic stage execution.
// Returns an AgenticLoop that wraps the internal loop infrastructure.
// Routes to API-based execution when API provider is configured.
func (p *Pipeline) createAgenticLoop(ctx context.Context, model string, prompt string, workDir string, maxIterations int) (blueprint.AgenticLoop, error) {
	// API mode: use HTTP provider instead of CLI subprocess
	if p.cfg.APIProvider != "" {
		return p.createAPIAgenticLoop(ctx, prompt, workDir, maxIterations)
	}

	// CLI mode: existing subprocess path
	// Build MCP config
	mcpPath, cleanup, err := p.buildMCPConfig()
	if err != nil {
		return nil, fmt.Errorf("build MCP config: %w", err)
	}

	cfg := loop.Config{
		ExecutorModel: model,
		Prompt:        prompt,
		WorkDir:       workDir,

		MaxIterations: maxIterations,
		MaxRetries:    p.cfg.MaxRetries,
		RetryBackoff:  p.cfg.RetryBackoff,
		MCPConfigPath: mcpPath,
		FwuID:         p.cfg.FWUID,
		ExecMode:      p.cfg.ExecMode,
		RunnerCommand: p.cfg.RunnerCommand,
		RunnerArgs:    p.cfg.RunnerArgs,
		CommandName:   p.cfg.CommandName,
		CommandArgs:   p.cfg.CommandArgs,
	}

	l, ch := loop.New(cfg)

	return &agenticLoopAdapter{
		loop:    l,
		events:  ch,
		cleanup: cleanup,
		emit:    p.emit,
	}, nil
}

// createAPIAgenticLoop creates an API-based agentic loop using an OpenAI-compatible provider.
func (p *Pipeline) createAPIAgenticLoop(ctx context.Context, prompt string, workDir string, maxTurns int) (blueprint.AgenticLoop, error) {
	// Resolve API key (support $ENV_VAR references)
	apiKey := p.cfg.APIKey
	if strings.HasPrefix(apiKey, "$") {
		apiKey = os.Getenv(strings.TrimPrefix(apiKey, "$"))
	}
	if apiKey == "" {
		return nil, fmt.Errorf("API key is required: set api_key in config or use $ENV_VAR reference")
	}

	// Create OpenAI provider with custom base URL
	providerCfg := pagent.OpenAIProviderConfig{
		APIKey:  apiKey,
		BaseURL: p.cfg.APIBaseURL,
		Name:    p.cfg.APIProvider,
	}

	// Allow the configured model through validation alongside the standard
	// OpenAI model list. Provider entries are user-named (e.g. "agentics-personal",
	// "vllm-local"), so we can't gate validation on the provider name.
	if p.cfg.APIModel != "" {
		providerCfg.Models = append(pagent.DefaultOpenAIModels(), p.cfg.APIModel)
	}

	provider, err := pagent.NewOpenAIProvider(providerCfg)
	if err != nil {
		return nil, fmt.Errorf("create API provider: %w", err)
	}

	// Build tool definitions for the API. When toolset filtering is enabled
	// and the local router has selected a specific toolset, send only that
	// toolset's tools instead of the full hardcoded list. See ADR-002.
	var tools []pagent.ToolDefinition
	if p.cfg.ToolsetFiltering && p.cfg.SelectedToolset != "" {
		registry := toolset.NewRegistry()
		if ts, ok := registry.Get(p.cfg.SelectedToolset); ok {
			tools = loop.BuildAPIToolDefinitionsFor(ts.Tools)
			log.Printf("[Pipeline] Toolset filtering: toolset=%s, %d/%d tools", p.cfg.SelectedToolset, len(tools), len(loop.BuildAPIToolDefinitions()))
		}
	}
	if tools == nil {
		tools = loop.BuildAPIToolDefinitions()
	}

	// Create event channel and runner
	ch := make(chan loop.Event, 100)
	runner := loop.NewAPIRunner(loop.APIRunnerConfig{
		Provider: provider,
		Model:    p.cfg.APIModel,
		Prompt:   prompt,
		WorkDir:  workDir,
		MaxTurns: maxTurns,
		Tools:    tools,
	}, ch)

	return &apiLoopAdapter{runner: runner, events: ch, emit: p.emit}, nil
}

// apiLoopAdapter wraps an APIRunner to implement blueprint.AgenticLoop.
type apiLoopAdapter struct {
	runner     *loop.APIRunner
	events     chan loop.Event
	emit       func(loop.Event)
	lastOutput string
	artifacts  map[string]string
}

// Run executes the API runner and captures results.
func (a *apiLoopAdapter) Run(ctx context.Context) error {
	a.artifacts = make(map[string]string)

	// Run in background
	runDone := make(chan error, 1)
	go func() { runDone <- a.runner.Run(ctx) }()

	// Consume events and capture output/artifacts
	for event := range a.events {
		a.emit(event)

		if event.Text != "" {
			a.lastOutput = event.Text
		}
		if event.Result != nil && event.Result.Artifacts != nil {
			for k, v := range event.Result.Artifacts {
				a.artifacts[k] = v
			}
		}
		if event.Artifacts != nil {
			for k, v := range event.Artifacts {
				a.artifacts[k] = v
			}
		}
	}

	return <-runDone
}

// GetResult returns the captured output and artifacts.
func (a *apiLoopAdapter) GetResult() (string, map[string]string, error) {
	return a.lastOutput, a.artifacts, nil
}

// agenticLoopAdapter wraps a loop.Loop to implement blueprint.AgenticLoop.
type agenticLoopAdapter struct {
	loop       *loop.Loop
	events     <-chan loop.Event
	cleanup    func()
	emit       func(loop.Event)
	lastOutput string
	artifacts  map[string]string
}

// Run executes the loop and captures results.
func (a *agenticLoopAdapter) Run(ctx context.Context) error {
	defer a.cleanup()

	a.artifacts = make(map[string]string)

	// Run loop in background
	loopDone := make(chan error, 1)
	go func() { loopDone <- a.loop.Run(ctx) }()

	// Consume events and capture output/artifacts
	for event := range a.events {
		// Forward event to pipeline
		a.emit(event)

		// Capture text output
		if event.Text != "" {
			a.lastOutput = event.Text
		}

		// Capture artifacts
		if event.Result != nil && event.Result.Artifacts != nil {
			for k, v := range event.Result.Artifacts {
				a.artifacts[k] = v
			}
		}
		if event.Artifacts != nil {
			for k, v := range event.Artifacts {
				a.artifacts[k] = v
			}
		}
	}

	return <-loopDone
}

// GetResult returns the captured output and artifacts.
func (a *agenticLoopAdapter) GetResult() (string, map[string]string, error) {
	return a.lastOutput, a.artifacts, nil
}

// gateRunnerAction adapts a types.GateRunner to the actions.Action interface.
type gateRunnerAction struct {
	runner  types.GateRunner
	receipt map[string]string // Private runner provenance, never populated from worker artifacts.
}

func (a *gateRunnerAction) Name() string {
	return "run_gates"
}

func (a *gateRunnerAction) terminalEvidence(bp *blueprint.Blueprint, run *blueprint.Run) map[string]string {
	if len(run.Results) == 0 || !gates.ValidateVerificationFailureArtifacts(a.receipt) {
		return nil
	}
	last := run.Results[len(run.Results)-1]
	stage, ok := bp.GetStage(last.StageName)
	if !ok || stage.Type != types.StageTypeDeterministic || last.Status != types.StageStatusFailed {
		return nil
	}
	// The receipt is captured by the actual local gate action in this stage.
	// Do not copy StageResult.Artifacts, which may be worker-controlled.
	// Include private references captured by this trusted runner alongside the receipt.
	retained := make(map[string]string, len(a.receipt))
	for key, value := range a.receipt {
		retained[key] = value
	}
	return retained
}

func (a *gateRunnerAction) Execute(ctx context.Context, req actions.ActionRequest) (actions.ActionResponse, error) {
	a.receipt = nil
	err := a.runner.RunAll(ctx)
	if err != nil {
		a.receipt = gates.VerificationFailureArtifacts(err)
		return actions.ActionResponse{
			Status:    types.StageStatusFailed,
			Output:    "Quality gates failed",
			Error:     err.Error(),
			Artifacts: a.receipt,
		}, nil
	}

	return actions.ActionResponse{
		Status: types.StageStatusCompleted,
		Output: "All quality gates passed",
	}, nil
}
