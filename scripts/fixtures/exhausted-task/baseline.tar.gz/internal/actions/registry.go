package actions

import (
	"fmt"
	"sync"
)

// Registry stores and retrieves registered actions.
type Registry struct {
	mu      sync.RWMutex
	actions map[string]Action
}

// NewRegistry creates a new empty action registry.
func NewRegistry() *Registry {
	return &Registry{
		actions: make(map[string]Action),
	}
}

// Register adds an action to the registry.
func (r *Registry) Register(a Action) error {
	r.mu.Lock()
	defer r.mu.Unlock()

	if _, exists := r.actions[a.Name()]; exists {
		return fmt.Errorf("action %q already registered", a.Name())
	}

	r.actions[a.Name()] = a
	return nil
}

// Overwrite adds an action to the registry, replacing any existing action with the same name.
func (r *Registry) Overwrite(a Action) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.actions[a.Name()] = a
}

// Get retrieves an action by name.
func (r *Registry) Get(name string) (Action, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()

	a, ok := r.actions[name]
	return a, ok
}

// DefaultRegistry returns a registry populated with built-in actions.
func DefaultRegistry(projectDir string) *Registry {
	r := NewRegistry()
	_ = r.Register(NewRunGatesAction(projectDir))
	_ = r.Register(NewBuildContextAction(projectDir))
	_ = r.Register(NewApplyPatchAction(projectDir))
	_ = r.Register(NewGenerateContractTestsAction(projectDir))
	_ = r.Register(NewChecklistRunAction(projectDir))
	return r
}
