package blueprint

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/openexec/openexec/internal/actions"
	"github.com/openexec/openexec/internal/contracts"
	"github.com/openexec/openexec/internal/execution/evidence"
	"github.com/openexec/openexec/internal/execution/gates"
	"github.com/openexec/openexec/internal/planner"
	"github.com/openexec/openexec/internal/skills"
	"github.com/openexec/openexec/internal/types"
)

// DefaultSmartZoneTokens is the peak single-call context size (in tokens)
// beyond which model quality degrades noticeably (the "dumb zone"). Agentic
// stages whose peak context exceeds the budget are flagged so the task can be
// split, instead of degrading silently.
const DefaultSmartZoneTokens = 100_000

// ArtifactPeakContextTokens is the artifact key under which agentic runners
// report the largest single-call context size (prompt + cache tokens of one
// call, NOT a cumulative sum across turns) observed during a stage.
const ArtifactPeakContextTokens = "peak_context_tokens"

// ArtifactSmartZoneExceeded marks a stage whose peak context size exceeded
// the smart-zone budget.
const ArtifactSmartZoneExceeded = "smart_zone_exceeded"

// DefaultExecutor executes blueprint stages.
// Deterministic stages run shell commands; agentic stages use bounded subloops.
type DefaultExecutor struct {
	// VerificationStages identifies exact server-configured check stages. It is
	// not deserialized from a blueprint or inferred from stage names/output.
	VerificationStages    map[*Stage]bool
	OnVerificationFailure func(*Stage, error)
	// WorkDir is the working directory for command execution.
	WorkDir string

	// Timeout is the default timeout for commands. If zero, 5 minutes is used.
	Timeout time.Duration

	// ActionRegistry contains deterministic Go-native actions.
	ActionRegistry *actions.Registry

	// AgenticRunner runs agentic stages. If nil, agentic stages fail.
	AgenticRunner AgenticRunner

	// SmartZoneTokens is the peak single-call context budget for agentic
	// stages. Zero means DefaultSmartZoneTokens; negative disables the check.
	SmartZoneTokens int64

	// SmartZoneHardStop promotes a smart-zone overrun from a flag to a stage
	// FAILURE: the stage's work is kept but the result fails with the
	// split-this-task diagnostic, so an orchestrator can stop and re-scope
	// instead of shipping a stage that ran over its context budget. Off by
	// default (flag-only, the historical behavior); NewDefaultExecutor also
	// honors OPENEXEC_SMART_ZONE_HARD_STOP=1.
	SmartZoneHardStop bool

	// OnCommandStart is called when a command starts.
	OnCommandStart func(stage *Stage, cmd string)

	// OnCommandComplete is called when a command completes.
	OnCommandComplete func(stage *Stage, cmd string, output string, err error)
}

// AgenticRunner executes agentic stages using an AI provider.
type AgenticRunner interface {
	// RunAgentic executes an agentic stage with the given prompt and returns output.
	RunAgentic(ctx context.Context, stage *Stage, input *StageInput) (string, map[string]string, error)
}

// NewDefaultExecutor creates a new default executor.
func NewDefaultExecutor(workDir string) *DefaultExecutor {
	v := strings.TrimSpace(os.Getenv("OPENEXEC_SMART_ZONE_HARD_STOP"))
	return &DefaultExecutor{
		WorkDir:           workDir,
		Timeout:           5 * time.Minute,
		SmartZoneHardStop: v == "1" || strings.EqualFold(v, "true"),
	}
}

// Execute runs a stage and returns the result.
func (e *DefaultExecutor) Execute(ctx context.Context, stage *Stage, input *StageInput) (*StageResult, error) {
	result := NewStageResult(stage.Name, 1)

	switch stage.Type {
	case types.StageTypeDeterministic:
		return e.executeDeterministic(ctx, stage, input, result)
	case types.StageTypeAgentic:
		return e.executeAgentic(ctx, stage, input, result)
	default:
		result.Fail(fmt.Sprintf("unknown stage type: %s", stage.Type))
		return result, fmt.Errorf("unknown stage type: %s", stage.Type)
	}
}

// executeDeterministic runs Go-native actions or shell commands for deterministic stages.
func (e *DefaultExecutor) executeDeterministic(ctx context.Context, stage *Stage, input *StageInput, result *StageResult) (*StageResult, error) {
	// 1. Try Action Registry first (Go-native logic)
	if stage.Action != "" && e.ActionRegistry != nil {
		if action, ok := e.ActionRegistry.Get(stage.Action); ok {
			inputs := map[string]any{"task_description": input.TaskDescription}
			for k, v := range stage.Inputs {
				inputs[k] = expandVars(v, input.Variables)
			}
			resp, err := action.Execute(ctx, actions.ActionRequest{
				RunID:        input.RunID,
				WorkspaceDir: e.WorkDir,
				Inputs:       inputs,
			})
			if err != nil {
				result.Fail(err.Error())
				return result, nil
			}
			result.Status = resp.Status
			result.Output = resp.Output
			result.Error = resp.Error
			result.Artifacts = resp.Artifacts

			// If action succeeded, still run quality gates if it wasn't the gates action itself.
			// Actually, if the action IS 'run_gates', we MUST still call runQualityGates
			// to ensure the internal state merging happens correctly.
			if result.Status == types.StageStatusCompleted {
				e.runQualityGates(ctx, stage, input, result)
			}
			return result, nil
		}
	}

	// 2. Fallback to shell commands
	if len(stage.Commands) > 0 {
		timeout := e.Timeout
		if stage.Timeout > 0 {
			timeout = stage.Timeout
		}

		var outputs []string
		for _, cmdStr := range stage.Commands {
			cmdCtx, cancel := context.WithTimeout(ctx, timeout)
			defer cancel()

			if e.OnCommandStart != nil {
				e.OnCommandStart(stage, evidence.Public(cmdStr, evidence.CommandSecrets(cmdStr)))
			}

			checkName := ""
			if e.VerificationStages[stage] {
				checkName = stage.Name
			}
			output, err := e.runCommandWithCheck(cmdCtx, cmdStr, checkName)
			outputs = append(outputs, output)

			if e.OnCommandComplete != nil {
				e.OnCommandComplete(stage, evidence.Public(cmdStr, evidence.CommandSecrets(cmdStr)), output, err)
			}

			if err != nil {
				if checkName != "" && e.OnVerificationFailure != nil {
					e.OnVerificationFailure(stage, err)
				}
				result.Output = strings.Join(outputs, "\n---\n")
				result.Fail(fmt.Sprintf("command failed: %v", err))
				return result, nil
			}
		}
		result.Output = strings.Join(outputs, "\n---\n")
		result.Complete("all commands succeeded")
	} else if stage.Action != "" {
		// The stage names an action the registry does not provide. Passing here
		// would report a gate as satisfied because its implementation is absent.
		result.Fail(fmt.Sprintf("stage %q declares action %q, which is not registered", stage.Name, stage.Action))
		return result, nil
	} else {
		// Nothing to run means nothing was verified, so this cannot be a pass.
		// The standard blueprint's lint and test stages ship with no commands and
		// take them from project config; when that is empty they arrive here.
		result.Fail(fmt.Sprintf("stage %q has no commands to run; set execution.%s_commands in .openexec/config.json, or remove the stage from the blueprint", stage.Name, stage.Name))
		return result, nil
	}

	// 3. Run Quality Gates (if configured and Action Registry available)
	e.runQualityGates(ctx, stage, input, result)

	return result, nil
}

// runQualityGates executes configured quality gates and merges results into the stage result.
func (e *DefaultExecutor) runQualityGates(ctx context.Context, stage *Stage, input *StageInput, result *StageResult) {
	if stage != nil && !stage.RunQualityGates {
		return
	}
	if e.ActionRegistry == nil {
		return
	}

	runGates, ok := e.ActionRegistry.Get("run_gates")
	if !ok {
		return
	}

	gateResp, err := runGates.Execute(ctx, actions.ActionRequest{
		RunID:        input.RunID,
		WorkspaceDir: e.WorkDir,
		Inputs:       map[string]any{"task_description": input.TaskDescription},
	})
	if err != nil {
		// Internal error running gates, don't fail the stage but log it
		result.Output += fmt.Sprintf("\n\n⚠ Warning: failed to run quality gates: %v", err)
		return
	}

	// Merge gate results
	if gateResp.Status == types.StageStatusFailed {
		result.Status = types.StageStatusFailed
		result.Error = fmt.Sprintf("Quality gates failed: %s", gateResp.Error)
		result.Output += "\n\n=== QUALITY GATE FAILURE ===\n" + gateResp.Output
	} else if gateResp.Output != "" {
		result.Output += "\n\n=== QUALITY GATES PASSED ===\n" + gateResp.Output
	}
}

// runCommand executes a shell command and returns its output.
func (e *DefaultExecutor) runCommand(ctx context.Context, cmdStr string) (string, error) {
	return e.runCommandWithCheck(ctx, cmdStr, "")
}

func (e *DefaultExecutor) runCommandWithCheck(ctx context.Context, cmdStr, checkName string) (string, error) {
	workDir := e.WorkDir
	if workDir == "" {
		workDir = "."
	}

	// Use sh -c to handle shell features like pipes and redirects
	cmd := exec.CommandContext(ctx, "sh", "-c", cmdStr) // #nosec G204
	cmd.Dir = workDir

	// Propagate environment
	cmd.Env = os.Environ()

	var stdout, stderr evidence.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err := cmd.Run()
	if checkName != "" {
		exitCode := -1
		if cmd.ProcessState != nil {
			exitCode = cmd.ProcessState.ExitCode()
		}
		hash, path, captureErr := evidence.Write(workDir, evidence.Command{
			Argv: cmd.Args, Cwd: cmd.Dir, ExitCode: exitCode, Stdout: stdout.String(), Stderr: stderr.String(),
			StdoutTruncated: stdout.Truncated, StderrTruncated: stderr.Truncated,
		})
		if captureErr != nil {
			return "", fmt.Errorf("private verification evidence could not be retained")
		}
		err = gates.CommandFailureWithEvidence(ctx, checkName, err, hash, path)
	}

	output := evidence.PublicStream(&stdout, evidence.CommandSecrets(cmdStr))
	if stderr.Len() > 0 {
		output += "\n[stderr]\n" + evidence.PublicStream(&stderr, evidence.CommandSecrets(cmdStr))
	}

	if err != nil {
		// Include stderr in error for better diagnostics
		if stderr.Len() > 0 {
			return output, fmt.Errorf("%w: %s", err, strings.TrimSpace(evidence.PublicStream(&stderr, evidence.CommandSecrets(cmdStr))))
		}
		return output, err
	}

	return output, nil
}

// executeAgentic runs an agentic stage using the AI provider.
func (e *DefaultExecutor) executeAgentic(ctx context.Context, stage *Stage, input *StageInput, result *StageResult) (*StageResult, error) {
	if e.AgenticRunner == nil {
		result.Fail("agentic runner not configured")
		return result, fmt.Errorf("agentic runner not configured")
	}

	timeout := e.Timeout
	if stage.Timeout > 0 {
		timeout = stage.Timeout
	}

	agenticCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	output, artifacts, err := e.AgenticRunner.RunAgentic(agenticCtx, stage, input)
	if err != nil {
		result.Fail(err.Error())
		return result, nil // Return result, not error
	}

	// Copy artifacts to result
	for k, v := range artifacts {
		result.AddArtifact(k, v)
	}

	result.Complete(output)

	// Flag smart-zone overruns so oversized tasks surface as a task-sizing
	// signal ("split this task") instead of degrading silently. With
	// SmartZoneHardStop the overrun FAILS the stage (work and artifacts are
	// kept — the failure is the re-scope signal, not a discard).
	if e.flagSmartZoneOverrun(result) && e.SmartZoneHardStop {
		result.Fail(result.Diagnostics)
		return result, nil
	}

	// Run Quality Gates after agentic stage succeeds
	e.runQualityGates(ctx, stage, input, result)

	return result, nil
}

// flagSmartZoneOverrun checks the stage's reported peak context size against
// the smart-zone budget and flags the result when the budget was exceeded,
// reporting whether it did. Stages whose runner did not report usage are left
// unflagged.
func (e *DefaultExecutor) flagSmartZoneOverrun(result *StageResult) bool {
	budget := e.SmartZoneTokens
	if budget < 0 {
		return false
	}
	if budget == 0 {
		budget = DefaultSmartZoneTokens
	}

	raw, ok := result.Artifacts[ArtifactPeakContextTokens]
	if !ok {
		return false
	}
	peak, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || peak <= budget {
		return false
	}

	result.AddArtifact(ArtifactSmartZoneExceeded, "true")
	msg := fmt.Sprintf("smart-zone budget exceeded: peak context %d tokens > budget %d — task is too big, split it into smaller tasks", peak, budget)
	if result.Diagnostics != "" {
		result.Diagnostics += "\n"
	}
	result.Diagnostics += msg
	log.Printf("[SmartZone] Stage %q: %s", result.StageName, msg)
	return true
}

// SimpleAgenticRunner is a basic agentic runner that uses a callback function.
type SimpleAgenticRunner struct {
	// RunFunc is called to execute the agentic stage.
	RunFunc func(ctx context.Context, stage *Stage, input *StageInput) (string, map[string]string, error)
}

// RunAgentic implements AgenticRunner.
func (r *SimpleAgenticRunner) RunAgentic(ctx context.Context, stage *Stage, input *StageInput) (string, map[string]string, error) {
	if r.RunFunc == nil {
		return "", nil, fmt.Errorf("RunFunc not set")
	}
	return r.RunFunc(ctx, stage, input)
}

// LoopAgenticRunner runs agentic stages using a bounded loop with the Loop infrastructure.
type LoopAgenticRunner struct {
	// LoopFactory creates a new loop for each agentic stage.
	// stageName is passed to allow model tiering (e.g. using Opus for 'review' stage).
	LoopFactory func(stageName string, prompt string, workDir string, maxIterations int) (AgenticLoop, error)

	// MaxIterations is the maximum iterations for the bounded subloop. Default 10.
	MaxIterations int
}

// AgenticLoop is a minimal interface for loop execution.
type AgenticLoop interface {
	Run(ctx context.Context) error
	GetResult() (string, map[string]string, error)
}

// RunAgentic implements AgenticRunner using a bounded loop.
func (r *LoopAgenticRunner) RunAgentic(ctx context.Context, stage *Stage, input *StageInput) (string, map[string]string, error) {
	if r.LoopFactory == nil {
		return "", nil, fmt.Errorf("LoopFactory not set")
	}

	maxIter := r.MaxIterations
	if maxIter <= 0 {
		maxIter = 10
	}

	// Build prompt from stage and input
	prompt := buildAgenticPrompt(stage, input)

	loop, err := r.LoopFactory(stage.Name, prompt, input.WorkingDirectory, maxIter)
	if err != nil {
		return "", nil, fmt.Errorf("failed to create loop: %w", err)
	}

	if err := loop.Run(ctx); err != nil {
		return "", nil, fmt.Errorf("loop execution failed: %w", err)
	}

	return loop.GetResult()
}

// buildAgenticPrompt constructs the prompt for an agentic stage.
func buildAgenticPrompt(stage *Stage, input *StageInput) string {
	var sb strings.Builder

	sb.WriteString("## Stage: ")
	sb.WriteString(stage.Name)
	sb.WriteString("\n\n")

	if stage.Description != "" {
		sb.WriteString(stage.Description)
		sb.WriteString("\n\n")
	}

	if stage.Prompt != "" {
		sb.WriteString(stage.Prompt)
		sb.WriteString("\n\n")
	}

	sb.WriteString("## Task\n")
	sb.WriteString(input.TaskDescription)
	sb.WriteString("\n\n")

	if input.Briefing != "" {
		sb.WriteString("## Project Context & Briefing\n")
		sb.WriteString(input.Briefing)
		sb.WriteString("\n\n")
	}

	// Add context from previous stages
	if len(input.PreviousStages) > 0 {
		sb.WriteString("## Previous Stage Results\n")
		for _, prev := range input.PreviousStages {
			sb.WriteString(fmt.Sprintf("- **%s** (%s): %s\n", prev.StageName, prev.Status, truncate(prev.Output, 500)))
		}
		sb.WriteString("\n")
	}

	// Add context files
	if len(input.ContextPack) > 0 {
		sb.WriteString("## Context Files\n")
		for path := range input.ContextPack {
			sb.WriteString("- ")
			sb.WriteString(path)
			sb.WriteString("\n")
		}
		sb.WriteString("\n")
	}

	// Stage-specific instructions
	switch stage.Name {
	case "implement":
		sb.WriteString("Implement the requested changes. Create new files with your Write tool, and use git_apply_patch or Edit for modifying existing files.\n")
		if section := completionContractForInput(input); section != "" {
			sb.WriteString(section)
		}
	case "fix_lint":
		sb.WriteString("Fix the linting errors from the previous stage. Use git_apply_patch or Edit for code modifications.\n")
	case "fix_tests":
		sb.WriteString("Fix the failing tests from the previous stage. Use git_apply_patch or Edit for code modifications.\n")
	case "review":
		sb.WriteString("Review the changes made in previous stages. Provide a summary of what was done and any concerns.\n")
		sb.WriteString("If this run surfaced a durable, project-specific lesson (a framework quirk, a recurring fix, a convention future sessions must know — NOT a one-off fix), capture it with the skill_propose tool. A human reviews proposals before they activate; do not propose more than one skill per run.\n")
		// Push project conventions to the reviewer. Implement stages rely on
		// pull (skill routing); the reviewer cannot verify compliance with
		// standards it never loaded, so conventions are injected here.
		if section := projectConventionsSection(input.WorkingDirectory); section != "" {
			sb.WriteString(section)
		}
	}

	sb.WriteString("\nWhen complete, emit an openexec_signal with type 'phase-complete'.\n")

	return sb.String()
}

// Limits for convention injection: deterministic gates already enforce
// machine-checkable standards, so this section carries only the project
// skills (naming, boundaries, architecture rules) and stays bounded.
const (
	maxConventionSkillChars = 4000
	maxConventionTotalChars = 12000
)

// projectConventionsSection loads active project-local skills and renders
// them as review criteria. Only the review stage receives this push —
// reviewing against standards requires having them in context, whereas
// implementers pull skills on demand via routing.
func projectConventionsSection(projectDir string) string {
	if projectDir == "" {
		return ""
	}
	reg := skills.NewRegistry()
	if err := reg.LoadFromDir(filepath.Join(projectDir, ".openexec", "skills"), "project"); err != nil {
		return ""
	}
	list := reg.List()
	if len(list) == 0 {
		return ""
	}
	sort.Slice(list, func(i, j int) bool { return list[i].Name < list[j].Name })

	var sb strings.Builder
	sb.WriteString("\n## Project Conventions (review the changes against ALL of these)\n")
	total := sb.Len()
	for _, sk := range list {
		content := strings.TrimSpace(sk.Content)
		if len(content) > maxConventionSkillChars {
			content = content[:maxConventionSkillChars] + "\n[truncated]"
		}
		entry := fmt.Sprintf("\n### %s — %s\n%s\n", sk.Name, sk.Description, content)
		if total+len(entry) > maxConventionTotalChars {
			sb.WriteString("\n[further conventions truncated — run `openexec skills list` for the full set]\n")
			break
		}
		sb.WriteString(entry)
		total += len(entry)
	}
	return sb.String()
}

// completionContractForInput returns the Completion Contract prompt
// block for the current feature if the stage input carries a
// contract_path and feature variable pointing at an entry in the
// blueprint's feature_completeness_contracts map. Returns empty if
// no contract is available.
func completionContractForInput(input *StageInput) string {
	if input == nil || len(input.Variables) == 0 {
		return ""
	}
	contractPath := input.Variables["contract_path"]
	feature := input.Variables["feature"]
	if contractPath == "" || feature == "" {
		return ""
	}
	cf, err := contracts.LoadFromYAML(contractPath)
	if err != nil || cf == nil {
		return ""
	}
	ops, ok := cf.Features[feature]
	if !ok || len(ops) == 0 {
		return ""
	}
	return planner.CompletionContractSection(feature, ops)
}

// expandVars performs simple ${var} substitution against vars. Keys
// that are not present in vars are left as-is.
func expandVars(s string, vars map[string]string) string {
	if s == "" || !strings.Contains(s, "${") || len(vars) == 0 {
		return s
	}
	out := s
	for k, v := range vars {
		out = strings.ReplaceAll(out, "${"+k+"}", v)
	}
	return out
}

// truncate shortens a string to maxLen, adding "..." if truncated.
func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
