// Package release provides release management with git integration and optional approval workflows.
package release

import (
	"time"
)

// Release represents a software release with git and approval tracking.
type Release struct {
	// Core fields
	Name        string `json:"name"`
	Version     string `json:"version"`
	Description string `json:"description,omitempty"`

	// Stories included in this release
	Stories []string `json:"stories"` // Story IDs

	// Git integration (populated when git tracking enabled)
	Git *ReleaseGitInfo `json:"git,omitempty"`

	// Approval workflow (populated when approval required)
	Approval *ApprovalInfo `json:"approval,omitempty"`

	// Lifecycle timestamps
	CreatedAt   time.Time  `json:"created_at"`
	StartedAt   *time.Time `json:"started_at,omitempty"`
	CompletedAt *time.Time `json:"completed_at,omitempty"`
	DeployedAt  *time.Time `json:"deployed_at,omitempty"`

	// Status: draft, in_progress, ready_for_approval, approved, deployed
	Status string `json:"status"`

	// Deployment targets (e.g., ["staging", "production"])
	DeployedTo []string `json:"deployed_to,omitempty"`

	// Generated changelog (markdown)
	Changelog string `json:"changelog,omitempty"`
}

// ReleaseGitInfo holds git-related information for a release.
type ReleaseGitInfo struct {
	Branch      string `json:"branch"`                 // e.g., "release/1.0.0"
	Tag         string `json:"tag,omitempty"`          // e.g., "v1.0.0"
	BaseBranch  string `json:"base_branch"`            // e.g., "main"
	MergeCommit string `json:"merge_commit,omitempty"` // Final merge to main
	HeadCommit  string `json:"head_commit,omitempty"`  // Latest commit on release branch
}

// Goal represents a high-level project objective.
type Goal struct {
	ID                 string `json:"id"`
	Title              string `json:"title,omitempty"`
	Description        string `json:"description"`
	SuccessCriteria    string `json:"success_criteria"`
	VerificationMethod string `json:"verification_method,omitempty"`
}

// Story represents a user story with git and approval tracking.
type Story struct {
	// Core fields
	ID          string  `json:"id"`                // e.g., "US-001"
	EpicID      *string `json:"epic_id,omitempty"` // Parent epic if any
	GoalID      string  `json:"goal_id,omitempty"` // Parent goal if any
	Title       string  `json:"title"`
	Description string  `json:"description,omitempty"` // Short description
	Role        string  `json:"role,omitempty"`        // As a <role>
	Want        string  `json:"want,omitempty"`        // I want <feature>
	Benefit     string  `json:"benefit,omitempty"`     // So that <benefit>

	// Acceptance criteria
	AcceptanceCriteria []string `json:"acceptance_criteria"`
	VerificationScript string   `json:"verification_script,omitempty"`
	Contract           string   `json:"contract,omitempty"`

	// Task references
	Tasks []string `json:"tasks"` // Task IDs

	// Dependencies
	DependsOn []string `json:"depends_on,omitempty"` // Story IDs this depends on

	// Classification
	StoryType string `json:"story_type"` // feature, bugfix, chore, refactor
	Priority  int    `json:"priority"`   // 0 = highest

	// Git integration (populated when git tracking enabled)
	Git *StoryGitInfo `json:"git,omitempty"`

	// Approval workflow (populated when approval required)
	Approval *ApprovalInfo `json:"approval,omitempty"`

	// Lifecycle
	Status      string     `json:"status"` // pending, in_progress, ready_for_review, approved, done
	CreatedAt   time.Time  `json:"created_at"`
	StartedAt   *time.Time `json:"started_at,omitempty"`
	CompletedAt *time.Time `json:"completed_at,omitempty"`
}

// StoryGitInfo holds git-related information for a story.
type StoryGitInfo struct {
	Branch      string     `json:"branch"`                 // e.g., "feature/US-001"
	BaseBranch  string     `json:"base_branch"`            // e.g., "release/1.0.0"
	MergedTo    string     `json:"merged_to,omitempty"`    // Branch it was merged into
	MergeCommit string     `json:"merge_commit,omitempty"` // Merge commit hash
	MergedAt    *time.Time `json:"merged_at,omitempty"`
	CommitCount int        `json:"commit_count,omitempty"` // Total commits on branch
}

// Task represents a work unit with git and approval tracking.
type Task struct {
	// Core fields
	ID          string `json:"id"` // e.g., "T-001"
	Title       string `json:"title"`
	Description string `json:"description,omitempty"`
	StoryID     string `json:"story_id"` // Parent story

	// Verification
	VerificationScript string `json:"verification_script,omitempty"`

	// Dependencies
	DependsOn []string `json:"depends_on,omitempty"` // Task IDs this depends on

	// Classification
	TaskType string `json:"task_type,omitempty"` // implementation, test, docs, fix
	Priority int    `json:"priority"`

	// Execution tracking
	AssignedAgent string `json:"assigned_agent,omitempty"`
	AttemptCount  int    `json:"attempt_count"`
	MaxAttempts   int    `json:"max_attempts"`

	// Git integration (populated when git tracking enabled)
	Git *TaskGitInfo `json:"git,omitempty"`

	// Approval workflow (populated when approval required)
	Approval *ApprovalInfo `json:"approval,omitempty"`

	// Review flags
	NeedsReview bool   `json:"needs_review"`
	ReviewNotes string `json:"review_notes,omitempty"`

	// Lifecycle
	Status       string     `json:"status"` // pending, in_progress, needs_review, approved, done, failed
	CreatedAt    time.Time  `json:"created_at"`
	StartedAt    *time.Time `json:"started_at,omitempty"`
	CompletedAt  *time.Time `json:"completed_at,omitempty"`
	ErrorMessage string     `json:"error_message,omitempty"`

	// Metadata for fix tracking
	Metadata map[string]interface{} `json:"metadata,omitempty"`
}

// ExecutionMode returns the task's execution mode (TaskModeAFK or TaskModeHITL).
// Tasks without an explicit mode default to AFK (autonomous).
func (t *Task) ExecutionMode() string {
	if t.Metadata != nil {
		if m, ok := t.Metadata["mode"].(string); ok && m == TaskModeHITL {
			return TaskModeHITL
		}
	}
	return TaskModeAFK
}

// TaskGitInfo holds git-related information for a task.
type TaskGitInfo struct {
	Commits  []string `json:"commits"`             // Commit hashes implementing this task
	Branch   string   `json:"branch,omitempty"`    // Branch where work was done
	PRNumber *int     `json:"pr_number,omitempty"` // Pull request number if applicable
	PRUrl    string   `json:"pr_url,omitempty"`    // Pull request URL
}

// ApprovalInfo holds approval workflow information.
type ApprovalInfo struct {
	// Approval state: pending, approved, rejected
	Status string `json:"status"`

	// Who approved/rejected
	ApprovedBy string `json:"approved_by,omitempty"`

	// When approved/rejected
	ApprovedAt *time.Time `json:"approved_at,omitempty"`

	// Approval comments/rationale
	Comments string `json:"comments,omitempty"`

	// For rejections: what needs to be fixed
	RejectionReason string `json:"rejection_reason,omitempty"`

	// Review cycle number (increments on each review request)
	ReviewCycle int `json:"review_cycle"`

	// Review requested timestamp
	ReviewRequestedAt *time.Time `json:"review_requested_at,omitempty"`
}

// ApprovalStatus constants
const (
	ApprovalPending  = "pending"
	ApprovalApproved = "approved"
	ApprovalRejected = "rejected"
)

// ReleaseStatus constants
const (
	ReleaseStatusDraft            = "draft"
	ReleaseStatusInProgress       = "in_progress"
	ReleaseStatusReadyForApproval = "ready_for_approval"
	ReleaseStatusApproved         = "approved"
	ReleaseStatusDeployed         = "deployed"
)

// StoryStatus constants
const (
	StoryStatusPending        = "pending"
	StoryStatusInProgress     = "in_progress"
	StoryStatusReadyForReview = "ready_for_review"
	StoryStatusApproved       = "approved"
	StoryStatusDone           = "done"
)

// TaskStatus constants
const (
	TaskStatusPending     = "pending"
	TaskStatusInProgress  = "in_progress"
	TaskStatusNeedsReview = "needs_review"
	TaskStatusApproved    = "approved"
	TaskStatusDone        = "done"
	TaskStatusFailed      = "failed"
)

// Task execution modes, stored in Task.Metadata["mode"].
// Mirrored by planner.TaskModeAFK/TaskModeHITL.
const (
	TaskModeAFK  = "afk"  // agent can complete and verify autonomously (default)
	TaskModeHITL = "hitl" // requires a human in the loop; never auto-dispatched
)

// Project phases derived from backlog state. The phase tells clients which
// lane fits: heavy mode does the initial intent → plan → build lifting;
// once that backlog is worked off, lightweight interactive work (light mode,
// chat) is usually all that is needed.
const (
	// PhaseNew: no stories exist — intent planning has not run.
	PhaseNew = "new"
	// PhasePlanned: a plan exists but no story has completed — the initial
	// heavy build run is still ahead.
	PhasePlanned = "planned"
	// PhaseBuilding: the initial build is underway (some stories done).
	PhaseBuilding = "building"
	// PhaseMaintaining: every story is done or approved — the heavy lifting
	// is complete and new work defaults to the lightweight lane.
	PhaseMaintaining = "maintaining"
)

// ComputePhase derives the project phase from its stories. Maintenance
// stories are excluded: surgical tasks filed after the initial build must
// not move a maintaining project back to building.
func ComputePhase(stories []*Story) string {
	counted, completed := 0, 0
	for _, st := range stories {
		if st.StoryType == StoryTypeMaintenance {
			continue
		}
		counted++
		if st.Status == StoryStatusDone || st.Status == StoryStatusApproved {
			completed++
		}
	}
	if counted == 0 {
		return PhaseNew
	}
	switch {
	case completed == 0:
		return PhasePlanned
	case completed == counted:
		return PhaseMaintaining
	default:
		return PhaseBuilding
	}
}

// StoryType constants
const (
	StoryTypeFeature  = "feature"
	StoryTypeBugfix   = "bugfix"
	StoryTypeChore    = "chore"
	StoryTypeRefactor = "refactor"
	// StoryTypeMaintenance is the rolling story that collects surgical work
	// filed from light mode after the initial build. It is excluded from
	// phase computation and from the one-story-at-a-time claim rule: a
	// one-off fix must not flip a maintaining project back to building.
	StoryTypeMaintenance = "maintenance"
)
