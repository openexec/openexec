package loop

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"strconv"
	"strings"

	"github.com/openexec/openexec/internal/blueprint"
	"github.com/openexec/openexec/internal/schema"
	"github.com/openexec/openexec/pkg/util"
)

// parserThrashThreshold is the number of consecutive identical tool failures
// before the parser emits EventThrashingDetected.
const parserThrashThreshold = 3

// Parser reads line-delimited stream-JSON from Claude Code and emits typed Events.
type Parser struct {
	events    chan<- Event
	iteration int
	tracker   *SignalTracker // optional, set by Loop for signal tracking

	// peakContextTokens is the largest single-call context size (input +
	// cache tokens) observed across assistant messages in this session.
	peakContextTokens int64

	// Cognitive-thrash detection: the stall detector only sees process
	// silence, so an agent that keeps regenerating the same failing tool
	// call (e.g. an identical broken patch after every rejection) looks
	// healthy. Track consecutive identical failures and flag them.
	lastToolName        string
	lastFailureSig      string
	consecutiveFailures int
	thrashWarned        bool
}

// NewParser creates a Parser that sends events to ch.
// iteration is the current loop iteration number stamped onto each event.
func NewParser(ch chan<- Event, iteration int) *Parser {
	return &Parser{events: ch, iteration: iteration}
}

// Parse reads from r until EOF, sending an Event for each recognized JSON line.
// Unrecognized or malformed lines are silently skipped.
func (p *Parser) Parse(r io.Reader) error {
	scanner := bufio.NewScanner(r)
	// Allow up to 1 MB per line (Claude Code can emit large tool inputs).
	scanner.Buffer(make([]byte, 0, 64*1024), 1024*1024)

	for scanner.Scan() {
		line := scanner.Bytes()
		if len(line) == 0 {
			continue
		}
		p.parseLine(line)
	}
	return scanner.Err()
}

// rawMessage is the top-level JSON envelope from stream-json output.
type rawMessage struct {
	Type    string          `json:"type"`
	Subtype string          `json:"subtype,omitempty"`
	Message json.RawMessage `json:"message,omitempty"`
	Result  json.RawMessage `json:"result,omitempty"`
	// tool_result fields
	Content json.RawMessage `json:"content,omitempty"`
}

// messageBody is the shape of the "message" field.
type messageBody struct {
	Content []contentItem `json:"content"`
	Usage   *usageBody    `json:"usage,omitempty"`
}

// usageBody is the per-call token usage attached to assistant messages.
type usageBody struct {
	InputTokens              int64 `json:"input_tokens"`
	CacheCreationInputTokens int64 `json:"cache_creation_input_tokens"`
	CacheReadInputTokens     int64 `json:"cache_read_input_tokens"`
	OutputTokens             int64 `json:"output_tokens"`
}

// contextTokens returns the context size of a single call: fresh input plus
// cache reads/writes (cached tokens still occupy the context window).
func (u *usageBody) contextTokens() int64 {
	return u.InputTokens + u.CacheCreationInputTokens + u.CacheReadInputTokens
}

// contentItem is a single item inside message.content[].
type contentItem struct {
	Type  string                 `json:"type"`
	Text  string                 `json:"text,omitempty"`
	Name  string                 `json:"name,omitempty"`
	Input map[string]interface{} `json:"input,omitempty"`
}

func (p *Parser) parseLine(line []byte) {
	var raw rawMessage
	if err := util.UnmarshalRobust(string(line), &raw); err != nil {
		return // malformed JSON — skip
	}

	switch raw.Type {
	case "system":
		// Session init — skip.
		return

	case "assistant":
		p.parseAssistant(raw.Message)

	case "tool_result":
		p.parseToolResult(raw.Content)

	case "result":
		// End of output — process about to exit. Surface the peak per-call
		// context size observed this session so the stage result can flag
		// smart-zone overruns (see blueprint.DefaultSmartZoneTokens).
		if p.peakContextTokens > 0 {
			p.emit(Event{
				Type:      EventProgress,
				Iteration: p.iteration,
				Artifacts: map[string]string{
					blueprint.ArtifactPeakContextTokens: strconv.FormatInt(p.peakContextTokens, 10),
				},
			})
		}
		return

	default:
		// Unrecognized — skip.
		return
	}
}

func (p *Parser) parseAssistant(data json.RawMessage) {
	if data == nil {
		return
	}

	// Emit activity heartbeat
	p.emit(Event{Type: EventProgress, Iteration: p.iteration})

	var body messageBody
	if err := util.UnmarshalRobust(string(data), &body); err != nil {
		return
	}

	// Track the largest single-call context size (peak, not cumulative —
	// each call re-sends the conversation, so summing would overcount).
	if body.Usage != nil {
		if ctx := body.Usage.contextTokens(); ctx > p.peakContextTokens {
			p.peakContextTokens = ctx
		}
	}

	for _, item := range body.Content {
		switch item.Type {
		case "text":
			p.emit(Event{
				Type:      EventAssistantText,
				Iteration: p.iteration,
				Text:      item.Text,
			})

			// Typed Schema Detection: Check for STEP_RESULT: {JSON} with validation
			if result, err := schema.DetectLegacyStepResult(item.Text); err == nil && result != nil {
				p.emit(Event{
					Type:      EventComplete,
					Iteration: p.iteration,
					Result: &StepResult{
						Status:      result.Status,
						Reason:      result.Reason,
						NextPhase:   result.NextPhase,
						Artifacts:   result.Artifacts,
						Confidence:  result.Confidence,
						Diagnostics: result.Diagnostics,
					},
				})
			}

			// Legacy completion signal detection (deprecated, use typed StepResult)
			if reason := schema.DetectCompletionSignal(item.Text); reason != "" {
				p.emitSignal(map[string]interface{}{
					"type":   "complete",
					"reason": reason,
				})
			}

			// Scope reconciliation detection
			txtLower := strings.ToLower(item.Text)
			if strings.Contains(txtLower, "planning mismatch") && strings.Contains(txtLower, "analysis reveals") {
				p.emitSignal(map[string]interface{}{
					"type": "progress",
					"text": "Reconciling task metadata based on agent analysis",
				})
			}
		case "tool_use":
			if isOpenExecSignal(item.Name) {
				p.emitSignal(item.Input)
			} else {
				p.lastToolName = item.Name
				p.emit(Event{
					Type:      EventToolStart,
					Iteration: p.iteration,
					Tool:      item.Name,
					ToolInput: item.Input,
				})
			}
		}
	}
}

func (p *Parser) parseToolResult(data json.RawMessage) {
	if data == nil {
		return
	}

	// Emit activity heartbeat
	p.emit(Event{Type: EventProgress, Iteration: p.iteration})

	// Content can be an array of items or a simple string.
	// Prefer array parsing to extract structured text and artifact markers.
	// Use standard json.Unmarshal here — tool results are well-formed JSON from the stream,
	// not LLM-generated text that needs sanitization.
	var items []contentItem
	if err := json.Unmarshal(data, &items); err == nil && len(items) > 0 {
		var b strings.Builder
		artifacts := map[string]string{}
		for _, it := range items {
			if it.Type == "text" && it.Text != "" {
				if b.Len() > 0 {
					b.WriteString("\n")
				}
				b.WriteString(it.Text)
				// Detect artifact markers like: ARTIFACT:patch <hash> <path>
				for _, line := range strings.Split(it.Text, "\n") {
					line = strings.TrimSpace(line)
					if strings.HasPrefix(line, "ARTIFACT:patch ") {
						parts := strings.SplitN(line, " ", 3)
						if len(parts) >= 3 {
							artifacts["patch_hash"] = parts[1]
							artifacts["patch_path"] = parts[2]
						}
					}
				}
			}
		}
		p.emit(Event{Type: EventToolResult, Iteration: p.iteration, Text: b.String(), Artifacts: artifacts})
		p.trackToolFailure(b.String())
		return
	}

	// Fallback to plain string
	var s string
	if err := json.Unmarshal(data, &s); err == nil {
		p.emit(Event{Type: EventToolResult, Iteration: p.iteration, Text: s})
		p.trackToolFailure(s)
		return
	}
	// Last resort: raw JSON string
	p.emit(Event{Type: EventToolResult, Iteration: p.iteration, Text: string(data)})
}

// trackToolFailure detects cognitive thrashing: an agent repeating the same
// failing tool call. Three consecutive identical failures emit a single
// EventThrashingDetected so the orchestrator and audit trail surface a loop
// that process-level stall detection cannot see (the agent is actively
// producing output the whole time).
func (p *Parser) trackToolFailure(text string) {
	lower := strings.ToLower(text)
	isFailure := strings.Contains(lower, "validation error") ||
		strings.Contains(lower, "invalid patch") ||
		strings.Contains(lower, "failed to apply patch") ||
		strings.HasPrefix(lower, "error:") ||
		strings.HasPrefix(lower, "error ")
	if !isFailure {
		p.lastFailureSig = ""
		p.consecutiveFailures = 0
		p.thrashWarned = false
		return
	}

	sig := p.lastToolName + "|" + lower
	if len(sig) > 200 {
		sig = sig[:200]
	}
	if sig == p.lastFailureSig {
		p.consecutiveFailures++
	} else {
		p.lastFailureSig = sig
		p.consecutiveFailures = 1
		p.thrashWarned = false
	}

	if p.consecutiveFailures >= parserThrashThreshold && !p.thrashWarned {
		p.thrashWarned = true
		p.emit(Event{
			Type:      EventThrashingDetected,
			Iteration: p.iteration,
			Tool:      p.lastToolName,
			Text: fmt.Sprintf("agent repeated the same failing %s call %d times in a row — likely thrashing, consider aborting or changing strategy",
				p.lastToolName, p.consecutiveFailures),
		})
	}
}

func (p *Parser) emit(e Event) {
	if p.events != nil {
		p.events <- e
	}
}

// isOpenExecSignal returns true if the tool name is an openexec_signal or axon_signal call.
// Handles both direct ("openexec_signal") and MCP-prefixed ("mcp__axon-signal__axon_signal").
func isOpenExecSignal(toolName string) bool {
	return strings.HasSuffix(toolName, "openexec_signal") || strings.HasSuffix(toolName, "axon_signal")
}

func (p *Parser) emitSignal(input map[string]interface{}) {
	sigType, _ := input["type"].(string)
	reason, _ := input["reason"].(string)
	target, _ := input["target"].(string)

	if p.tracker != nil {
		p.tracker.RecordSignal(sigType, p.iteration)
	}

	p.emit(Event{
		Type:         EventSignalReceived,
		Iteration:    p.iteration,
		SignalType:   sigType,
		SignalTarget: target,
		Text:         reason,
	})
}
