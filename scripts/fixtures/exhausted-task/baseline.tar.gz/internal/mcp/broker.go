package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"github.com/openexec/openexec/internal/toolset"
	"github.com/openexec/openexec/pkg/telemetry"
	"go.opentelemetry.io/otel/trace"
)

// PermissionMode defines the execution tier.
type PermissionMode string

const (
	ModeSuggest  PermissionMode = "suggest"            // Read-only + Propose Patch
	ModeAutoEdit PermissionMode = "auto-edit"          // Apply Patch + Read-only
	ModeFullAuto PermissionMode = "danger-full-access" // Command allowlist + write_file
)

// ToolBroker enforces tiered permissions across all MCP tools.
type ToolBroker struct {
	mode            PermissionMode
	runID           string            // Current run ID for tracing
	toolsetRegistry *toolset.Registry // Optional toolset-based filtering
	activeToolset   string            // Currently active toolset
	symbolsOnly     bool              // Restrict to repository symbol tools
}

// SetRunID sets the current run ID for tracing context.
func (b *ToolBroker) SetRunID(runID string) {
	b.runID = runID
}

// SetToolsetRegistry configures toolset-based authorization.
func (b *ToolBroker) SetToolsetRegistry(registry *toolset.Registry) {
	b.toolsetRegistry = registry
}

// SetActiveToolset sets the currently active toolset for authorization.
func (b *ToolBroker) SetActiveToolset(name string) {
	b.activeToolset = name
}

// StartToolSpan creates a traced span for a tool invocation.
// Returns the context with span and a function to end the span.
func (b *ToolBroker) StartToolSpan(ctx context.Context, toolName string, args map[string]interface{}) (context.Context, trace.Span) {
	return telemetry.StartToolSpan(ctx, b.runID, toolName, args)
}

// Mode returns the current permission mode.
func (b *ToolBroker) Mode() PermissionMode {
	return b.mode
}

// NewToolBroker creates a broker based on the current environment or config.
func NewToolBroker(modeOverride string) *ToolBroker {
	modeStr := modeOverride
	if modeStr == "" {
		modeStr = os.Getenv("OPENEXEC_MODE")
	}
	mode := PermissionMode(modeStr)

	// Normalize and apply secure default
	switch mode {
	case ModeSuggest, ModeAutoEdit, ModeFullAuto:
		// valid
	default:
		mode = ModeAutoEdit // Secure default: Allow patches but no shell/write_file
	}

	return &ToolBroker{mode: mode}
}

// IsSymbolTool reports whether a name is one of the read-only repository
// graph lookups.
func IsSymbolTool(name string) bool {
	switch name {
	case "symbol_find", "symbol_read", "symbol_relations":
		return true
	}
	return false
}

// SetSymbolsOnly restricts this broker to the repository symbol tools.
//
// Enforced here rather than only in handleToolsList because advertisement is
// not authorization: a client that already knows a tool name can call it
// without ever listing. This is the profile Agent Console runs, so the deny
// must be the authoritative one.
func (b *ToolBroker) SetSymbolsOnly(only bool) {
	b.symbolsOnly = only
}

// Authorize checks if a tool call is permitted in the current mode and toolset.
func (b *ToolBroker) Authorize(toolName string, arguments string) (bool, string) {
	// Symbols-only profile: deny everything else outright, before any
	// mode or toolset reasoning can widen it.
	if b.symbolsOnly && !IsSymbolTool(toolName) {
		return false, fmt.Sprintf("[Symbols-only] tool '%s' is not available; this server exposes only symbol_find, symbol_read and symbol_relations", toolName)
	}

	// Check toolset-based authorization first (if configured)
	if b.toolsetRegistry != nil && b.activeToolset != "" {
		ts, ok := b.toolsetRegistry.Get(b.activeToolset)
		if ok && b.toolsetRegistry.IsEnabled(b.activeToolset) {
			// Control plane tools are always allowed. Infra tools are a
			// separate capability plane outside the coding-toolset taxonomy:
			// the toolset filter does not apply to them because their own
			// registry (.openexec/infra.yaml, deny-by-default) is a stricter
			// boundary — but they remain mode-gated below.
			if !isControlPlaneTool(toolName) && !isInfraTool(toolName) && !isApprovalTool(toolName) && !ts.HasTool(toolName) {
				return false, fmt.Sprintf("[Toolset %s] tool '%s' is not available in the current toolset", b.activeToolset, toolName)
			}
		}
	}

	// Mode-based authorization (existing logic)
	switch toolName {
	case "read_file", "axon_signal", "openexec_signal", "get_fork_info", "list_session_forks", "fork_session",
		"openexec_result", "openexec_action":
		return true, "" // Always allowed (Read-only or control plane)

	case "backlog_list_stories", "backlog_get_story", "memory_read":
		return true, "" // Read-only backlog/memory access, allowed in every mode

	case "symbol_find", "symbol_read", "symbol_relations":
		// Repository graph lookups (symbols.go). These never write workspace
		// files; symbol_read returns source the caller could already obtain
		// with read_file. They can refresh the graph index as a side effect —
		// the V2.1 read gate recomputes a drifted generation rather than
		// answering from a stale one — which mutates orchestrator bookkeeping
		// (.openexec), the same documented exception the backlog writes use.
		// Allowed in every mode so even read-only chat locates code by pointer
		// instead of scanning files.
		return true, ""

	case "backlog_claim_story", "backlog_complete_task", "backlog_complete_story", "backlog_add_task":
		// Backlog state writes are allowed in every mode, including read-only
		// chat: they mutate orchestrator bookkeeping (the .openexec database),
		// not workspace files. This is the documented light-mode exception
		// that lets an external MCP client (e.g. Claude Code) drive the
		// backlog one story at a time.
		return true, ""

	case "skill_propose":
		// Skill proposals are allowed in every mode: they write a CANDIDATE
		// under .openexec/skills/_candidates/ that is never loaded until a
		// human approves it — proposing carries no execution-time risk.
		return true, ""

	case "git_apply_patch":
		if b.mode == ModeSuggest {
			// In suggest mode, only allow dry-run (check_only=true)
			var args struct {
				CheckOnly bool `json:"check_only"`
			}
			if err := json.Unmarshal([]byte(arguments), &args); err != nil || !args.CheckOnly {
				return false, "[Suggest Mode] git_apply_patch requires check_only=true; propose patches as reasoning text for manual apply"
			}
		}
		return true, ""

	case "write_file":
		if b.mode != ModeFullAuto {
			return false, "[Security] write_file is restricted to Full Auto (danger) mode; please use git_apply_patch for workspace edits"
		}
		return true, ""

	case "run_shell_command":
		if b.mode != ModeFullAuto {
			return false, fmt.Sprintf("[%s Mode] run_shell_command is disabled; switch to Full Auto (danger) mode to enable shell access", b.mode)
		}
		return b.validateShellCommand(arguments)

	case "approval_list", "approval_decide":
		// Operator sign-off tools: permitted in every permission mode — the
		// human operator approving from a read-only light session is the
		// whole point. The real guard is the operator-session check in the
		// handler (OPENEXEC_OPERATOR_SESSION read once at server start):
		// an agent session can name these tools but never use them.
		return true, ""

	case "ansible_run_playbook", "salt_apply_state", "ssh_run_query", "terraform_plan", "terraform_apply":
		// Infra tools execute processes against real infrastructure, so —
		// like run_shell_command — all of them require danger-full-access
		// mode, uniformly (read-class included; relax later only if real use
		// demands it). Inside that mode the real shields take over: the
		// deny-by-default infra registry validates every parameter, and
		// apply-class invocations additionally require the approval gate
		// (fail-closed when none is wired). See infra.go.
		if b.mode != ModeFullAuto {
			return false, fmt.Sprintf("[%s Mode] infra tool '%s' requires danger-full-access mode", b.mode, toolName)
		}
		return true, ""

	default:
		// For safety, restrict unknown tools in all but Full Auto
		if b.mode != ModeFullAuto {
			return false, fmt.Sprintf("[%s Mode] unknown tool '%s' is restricted", b.mode, toolName)
		}
		return true, ""
	}
}

// isControlPlaneTool returns true for tools that are always allowed regardless of toolset.
func isControlPlaneTool(toolName string) bool {
	controlPlaneTools := map[string]bool{
		"axon_signal":        true,
		"openexec_signal":    true,
		"openexec_result":    true,
		"openexec_action":    true,
		"get_fork_info":      true,
		"list_session_forks": true,
		"fork_session":       true,
		// Backlog/memory tools are control plane: they manage orchestrator
		// state, not workspace files, so toolset filtering never blocks them.
		"backlog_list_stories":   true,
		"backlog_get_story":      true,
		"backlog_claim_story":    true,
		"backlog_complete_task":  true,
		"backlog_complete_story": true,
		"backlog_add_task":       true,
		"memory_read":            true,
		"skill_propose":          true,
	}
	return controlPlaneTools[toolName]
}

func (b *ToolBroker) validateShellCommand(arguments string) (bool, string) {
	// In full-auto (danger) mode, allow all commands without restriction
	if b.mode == ModeFullAuto {
		return true, ""
	}

	// Implementation of allowlist logic for restricted modes
	allowedCommands := map[string]bool{
		"go": true, "npm": true, "ls": true, "pwd": true, "git": true,
		"cat": true, "grep": true, "find": true, "mkdir": true, "rm": true,
		"touch": true, "cp": true, "mv": true, "chmod": true, "chown": true,
		"pytest": true, "ruff": true, "mypy": true, "black": true, "isort": true,
		"tsc": true, "vitest": true, "eslint": true, "prettier": true, "python": true, "python3": true,
		"uv": true, "pip": true, "poetry": true, "make": true, "just": true,
		"echo": true, "printf": true, "wc": true, "sleep": true, "head": true, "tail": true,
		"bash": true, "sh": true, "date": true, "env": true, "exit": true,
		"seq": true, "sort": true, "uniq": true, "tr": true, "cut": true, "awk": true, "sed": true,
		"printenv": true, "which": true, "whoami": true, "uname": true,
	}

	// Parse JSON arguments to extract command
	var args struct {
		Command string `json:"command"`
	}
	if err := json.Unmarshal([]byte(arguments), &args); err != nil {
		return false, "invalid command arguments"
	}

	fields := strings.Fields(args.Command)
	if len(fields) == 0 {
		return false, "empty command"
	}

	baseCmd := fields[0]
	if !allowedCommands[baseCmd] {
		return false, "command '" + baseCmd + "' is not in the allowlist"
	}

	return true, ""
}
